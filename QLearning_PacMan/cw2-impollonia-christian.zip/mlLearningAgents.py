# mlLearningAgents.py
# parsons/27-mar-2017
#
# A stub for a reinforcement learning agent to work with the Pacman
# piece of the Berkeley AI project:
#
# http://ai.berkeley.edu/reinforcement.html
#
# As required by the licensing agreement for the PacMan AI we have:
#
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).

# This template was originally adapted to KCL by Simon Parsons, but then
# revised and updated to Py3 for the 2022 course by Dylan Cope and Lin Li

from __future__ import absolute_import
from __future__ import print_function
from gc import get_count

import random

from pacman import Directions, GameState
from pacman_utils.game import Agent
from pacman_utils import util


class GameStateFeatures:
    """
    Wrapper class around a game state where you can extract
    useful information for your Q-learning algorithm

    WARNING: We will use this class to test your code, but the functionality
    of this class will not be tested itself
    """

    def __init__(self, state: GameState):
        """
        Args:
            state: A given game state object
        """
        self.state = state
    
    def getLegalActions(self):
        return self.state.getLegalPacmanActions()



class QLearnAgent(Agent):

    def __init__(self,
                 alpha: float = 0.3,
                 epsilon: float = 0.025,
                 gamma: float = 0.95,
                 maxAttempts: int = 45,
                 numTraining: int = 10):
        """
        These values are either passed from the command line (using -a alpha=0.5,...)
        or are set to the default values above.

        The given hyperparameters are suggestions and are not necessarily optimal
        so feel free to experiment with them.

        Args:
            alpha: learning rate
            epsilon: exploration rate
            gamma: discount factor
            maxAttempts: How many times to try each action in each state
            numTraining: number of training episodes
        """
        super().__init__()
        self.alpha = float(alpha)
        self.epsilon = float(epsilon)
        self.gamma = float(gamma)
        self.maxAttempts = int(maxAttempts)
        self.numTraining = int(numTraining)
        # Count the number of games we have played
        self.episodesSoFar = 0

        #Initialize the Q table as an empty dictionary
        self.Q = {}

        #Initialize the count as an empty dictionary
        self.count = {}

    # Accessor functions for the variable episodesSoFar controlling learning
    def incrementEpisodesSoFar(self):
        self.episodesSoFar += 1

    def getEpisodesSoFar(self):
        return self.episodesSoFar

    def getNumTraining(self):
        return self.numTraining

    # Accessor functions for parameters
    def setEpsilon(self, value: float):
        self.epsilon = value

    def getEpsilon(self):
        return self.epsilon

    def getAlpha(self) -> float:
        return self.alpha

    def setAlpha(self, value: float):
        self.alpha = value

    def getGamma(self) -> float:
        return self.gamma

    def getMaxAttempts(self) -> int:
        return self.maxAttempts

    # WARNING: You will be tested on the functionality of this method
    # DO NOT change the function signature

    # Obtains the reward of the state transition by comparing the score of the game before the transition happens, 
    # and after the transition happens. The difference between the new score and the old score is the returned reward 
    @staticmethod
    def computeReward(startState: GameState,
                      endState: GameState) -> float:
        """
        Args:
            startState: A starting state
            endState: A resulting state

        Returns:
            The reward assigned for the given trajectory
        """
        return (endState.getScore() - startState.getScore())

    # WARNING: You will be tested on the functionality of this method
    # DO NOT change the function signature

    #This function will obtain the Q Value of a specific state-action pair by looking up the Q dictionary
    #for that pair (given as input). If the value is in the dictionary, it will return it. If not, it will just return 0. 
    def getQValue(self,
                  state: GameStateFeatures,
                  action: Directions) -> float:
        """
        Args:
            state: A given state
            action: Proposed action to take

        Returns:
            Q(state, action)
        """
        key = (state, action)
        if key in self.Q.keys():
            return self.Q[(state, action)]
        else:
            return 0

    # WARNING: You will be tested on the functionality of this method
    # DO NOT change the function signature

    #This function calculates the best Q Value from a given state, by obtaining all the legal actions
    #from that given state, and then computing the Q value from each state-action pair, returning the max of those.
    #In case there are no legal actions from the input state, the function will return 0.
    def maxQValue(self, state: GameStateFeatures) -> float:
        """
        Args:
            state: The given state

        Returns:
            q_value: the maximum estimated Q-value attainable from the state
        """
        actions = state.getLegalActions()
        if actions:
            max = 0
            for action in actions:
                qValue = self.getQValue(state, action)
                if qValue > max:
                    max = qValue
            return max
        else:
            return 0


    # WARNING: You will be tested on the functionality of this method
    # DO NOT change the function signature

    #This is the main function that updates the Q Value of a state action pair. It does it using value iteration.
    #The new Q Value for the input state-action pair is the old Q Value plus the learning rate alpha multiplied by 
    #(the reward for the input state, plus the discounted max Q Value of the next state, minus the Q value of this state)
    def learn(self,
              state: GameStateFeatures,
              action: Directions,
              reward: float,
              nextState: GameStateFeatures):
        """
        Performs a Q-learning update

        Args:
            state: the initial state
            action: the action that was taken
            nextState: the resulting state
            reward: the reward received on this trajectory
        """
        qValue = self.getQValue(state, action)
        self.Q[(state, action)] = qValue + (self.getAlpha() * (reward + (self.getGamma() * self.maxQValue(nextState)) - qValue))

    # WARNING: You will be tested on the functionality of this method
    # DO NOT change the function signature

    #This function updates the count of how many times a specific action has been used in a specific state,
    #by simply incrementing by 1 the value for that specific entry in the count dictionary. If the entry for state-action
    #pair is not found, it is assumed it has never occurred and it has value 0, so 1 is returned as it is incremented.
    def updateCount(self,
                    state: GameStateFeatures,
                    action: Directions):
        """
        Updates the stored visitation counts.

        Args:
            state: Starting state
            action: Action taken
        """
        key = (state, action)
        if key in self.count.keys():
            self.count[state, action] += 1
        else:
            self.count[state, action] = 1

    # WARNING: You will be tested on the functionality of this method
    # DO NOT change the function signature

    #This function just returns the value in the dictionary count for a given state-action pair, telling 
    # how many times it occurred in that state
    def getCount(self,
                 state: GameStateFeatures,
                 action: Directions) -> int:
        """
        Args:
            state: Starting state
            action: Action taken

        Returns:
            Number of times that the action has been taken in a given state
        """
        key = (state, action)
        if key in self.count.keys():
            return self.count[state, action]
        else:
            return 0

    # WARNING: You will be tested on the functionality of this method
    # DO NOT change the function signature

    #This function helps the agent explore more of the world before starting exploiting. Given a utility and the amount of times
    #that action has been run in that state, if the count is less than maxAttempts(or Ne in the theory) it will output a more optimistic 
    #reward Rplus, while if it more than the maxAttempts it will output the real utility. 
    #The values chosen for Ne and Rplus were the ones that gave the most accurate results, but they can be changed accordingly 
    #to find the best match
    def explorationFn(self,
                      utility: float,
                      counts: int) -> float:
        """
        Computes exploration function.
        Return a value based on the counts

        HINT: Do a greed-pick or a least-pick

        Args:
            utility: expected utility for taking some action a in some given state s
            counts: counts for having taken visited

        Returns:
            The exploration value
        """
        RPLUS = utility + 15

        if counts < self.getMaxAttempts():
            return RPLUS
        else:
            return utility

    # WARNING: You will be tested on the functionality of this method
    # DO NOT change the function signature

    #The main function that handles the movement of the agent. It uses an epsilon-greedy approach, so with epsilon chance
    #it will run a random action, to make the agent keep exploring. Most of the times, it will use the functions created before, and pick
    #the action with the best possible Q Value, updating it every time.
    def getAction(self, state: GameState) -> Directions:
        """
        Choose an action to take to maximise reward while
        balancing gathering data for learning

        If you wish to use epsilon-greedy exploration, implement it in this method.
        HINT: look at pacman_utils.util.flipCoin

        Args:
            state: the current state

        Returns:
            The action to take
        """
        # The data we have about the state of the game
        legal = state.getLegalPacmanActions()
        if Directions.STOP in legal:
            legal.remove(Directions.STOP)

        # logging to help you understand the inputs, feel free to remove
        #print("Legal moves: ", legal)
        #print("Pacman position: ", state.getPacmanPosition())
        #print("Ghost positions:", state.getGhostPositions())
        #print("Food locations: ")
        #print(state.getFood())
        #print("Score: ", state.getScore())

        stateFeatures = GameStateFeatures(state)

        # Now pick what action to take.
        # With epsilon chance it will pick randomly, in other cases it will calculate the utility with the reward obtained 
        # by looking at the current state and next state

        if util.flipCoin(self.getEpsilon()):
            return random.choice(legal)
        else:
            #gets the q values of all the possible actions, puts highest ones in an array (could be more than one)
            maxValue = self.getQValue(state, legal[0])
            maxAction = legal[0]
            bestActions = []
            for action in legal:
                value = self.explorationFn(self.getQValue(state, action), self.getCount(state, action))
                if value > maxValue:
                    bestActions.clear()
                    maxValue = value
                    maxAction = action
                else:
                    if value == maxValue and action != maxAction:
                        bestActions.append(maxAction)
                        maxValue = value
                        maxAction = action
            bestActions.append(maxAction)

            #chooses at random one of the best actions selected before
            bestAction = random.choice(bestActions)

            #calculates the next state to then update the q table with the new utility for the state-action pair
            nextState = state.generateSuccessor(0, bestAction)
            self.learn(state, bestAction, self.computeReward(state, nextState), nextState)

            return bestAction


    #the function called when a game is ended, which mostly removes the training-only hyperparameters
    def final(self, state: GameState):
        """
        Handle the end of episodes.
        This is called by the game after a win or a loss.

        Args:
            state: the final game state
        """
        print(f"Game {self.getEpisodesSoFar()} just ended!")

        # Keep track of the number of games played, and set learning
        # parameters to zero when we are done with the pre-set number
        # of training episodes
        self.incrementEpisodesSoFar()
        if self.getEpisodesSoFar() == self.getNumTraining():
            msg = 'Training Done (turning off epsilon and alpha)'
            print('%s\n%s' % (msg, '-' * len(msg)))
            self.setAlpha(0)
            self.setEpsilon(0)

            
            

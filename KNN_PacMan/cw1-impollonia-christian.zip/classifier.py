# classifier.py
# Lin Li/26-dec-2021
#
# Use the skeleton below for the classifier and insert your code here.

#Implementation of a simple 1-nearest-neighbor classifier to choose the best move

class Classifier:
    def __init__(self):
        #initializes the counter used to choose a move when the best move isn't legal
        self.rand_count = -1

    def reset(self):
        #resets the counter at the end
        self.rand_count = -1
    

    #As a knn algorithm doesn't have a training process, the fit function is just the storing of the training sets data and target

    def fit(self, data, target):
        self.x_train = data
        self.y_train = target


    #For the "distance" between the current state of the world pacman is in (x_test) and a state from the training data (x_train_curr), 
    #I decided to compare the two states element by element, as they are represented only as a series of 0s and 1s. Every time two 0s 
    # or two 1s between the two states are in common (so in the same position) we add 1 to the count, and this sum represent how "close"
    # the current state is to the state being compared. So the "distance" between them is the number of times they have different digits 
    # in the same location. So in practice, if we consider the two numbers as binary and not integers, they can be xor'd, and then 
    # the number of 1s of this distance vector can be counted. That will be the distance.

    def state_distance(self, x_test, x_train_curr):
        bin_test = int("0b" + ''.join(str(e) for e in x_test), base = 2)
        bin_train_curr = int("0b" + ''.join(str(e) for e in x_train_curr), base = 2)
        dist_vector = str(bin_test ^ bin_train_curr)
        count = 0
        for i in dist_vector:
            if i == "1":
                count += 1
        return count        



        

    #The main function which predicts the next best move. It works by using the state_distance function above to calculate the distance
    #of the current state to every single feature in the training set. It then chooses the smallest from the array of distances, and uses
    #as best move the move coming from that index, assuming it is a legal move. If the move isn't legal, it will choose a pseudo-random 
    #move obtained by just increasing a counter by 1 every time this happens and choosing a move from the legal list with that counter as 
    #index

    def predict(self, data, legal=None):
        distances = []
        for i in range(len(self.x_train)):
            distances.append(self.state_distance(data, self.x_train[i]))
        min_dist = 1000
        min_i = 0
        for i in range(len(self.x_train)):
            if distances[i] < min_dist:
                min_dist = distances[i]
                min_i = i
        best_move = self.y_train[min_i]
        if (best_move in legal):
            return best_move
        else:
            self.rand_count += 1
            return legal[self.rand_count % len(legal)]
        

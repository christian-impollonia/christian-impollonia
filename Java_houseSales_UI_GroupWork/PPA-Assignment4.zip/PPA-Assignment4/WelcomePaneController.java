import javafx.fxml.FXML;
import javafx.scene.control.Label;

/**
 * A simple controller for the welcome window.
 * It provides the logic for the elements inside the welcome pane.
 *
 * @author Alfredo Musumeci
 * @version 2020/03/14
 */
public class WelcomePaneController {
    // Label to display the price info.
    @FXML
    private Label priceDisplay;

    /**
     * Display information about the price range selected.
     * @param fromPrice The starting price.
     * @param toPrice The "to" price.
     */
    public void setPriceDisplay(int fromPrice, int toPrice){
        priceDisplay.setText("The price range you have selected goes from " + fromPrice + " to " + toPrice + ".");
    }
}
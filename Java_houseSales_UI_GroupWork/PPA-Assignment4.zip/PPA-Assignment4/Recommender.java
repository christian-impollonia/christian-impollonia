import java.util.ArrayList;
import java.util.List;

/**
 * This class calculates the five properties that are most likely to interest the user, based on price, reviews
 * and other factors. It implements an algorithm that gives points to each property based on how they compare with
 * the average. It then shows the properties on the fourth (extra) pane using the RecommenderController.
 *
 * @author Christian Impollonia
 * @version 2020.03.25
 */
public class Recommender {
    // The properties filtered by the user for price.
    private List<AirbnbListing> selectedProperties;
    // The recommended properties calculated.
    private List<AirbnbListing> calculatedProperties = new ArrayList<>();
    // The average of the price of properties.
    private float priceAverage;
    // The average of property availability throughout the year.
    private float availabilityAverage;
    // The average number of reviews per property.
    private float reviewAverage;
    // The average number of host listings per property.
    private float hostListingsAverage;
    // The average number of minimum nights someone can stay.
    private float minimumNightsAverage;


    /**
     * Gets the list of properties in the user's price range
     * @param selectedPropertiesList List of properties within price range.
     */
    public void setPropertiesList(List<AirbnbListing> selectedPropertiesList) {
        this.selectedProperties = selectedPropertiesList;
    }

    /**
     * Returns the array of calculated properties, by giving points to each property based on price, number of reviews,
     * availability throughout the year, minimum staying nights and number of listings by host.
     * @return Array of calculated properties.
     */
    public List<AirbnbListing> getCalculatedProperties()
    {
         return calculatedProperties;
    }

    /**
     * Calculates the recommended properties by picking the properties with the highest amount of points.
     * It uses many highly cohesive methods to simplify testing and make it more accurate.
     */
    public void calculateProperties() {
        calculatedProperties.clear();
        ArrayList<Integer> pointsArray = new ArrayList<>();
        for(AirbnbListing ignored : selectedProperties) {
            pointsArray.add(0);
        }
        calculatePriceAverage();
        calculateAvailabilityAverage();
        calculateReviewAverage();
        calculateHostListingsAverage();
        calculateMinimumNightsAverage();
        givePricePoints(pointsArray);
        giveAvailabilityPoints(pointsArray);
        giveReviewPoints(pointsArray);
        giveHostListingsPoints(pointsArray);
        giveMinimumNightsPoints(pointsArray);
        //creates a clone of the selected properties list, to make sure that when properties are deleted it won't affect the original list
        ArrayList<AirbnbListing> selectedPropertiesClone = new ArrayList<>();
        for(AirbnbListing listing : selectedProperties) {
            selectedPropertiesClone.add(listing);
        }
        for(int j= 0; j<5; j++) {
            float max = pointsArray.get(0);
            int storedIndex = 0;
            for (int i = 1; i < pointsArray.size(); i++) {
                if (pointsArray.get(i) > max) {
                    max = pointsArray.get(i);
                    storedIndex = i;
                }
            }
            if(!selectedPropertiesClone.isEmpty()) {
                calculatedProperties.add(selectedPropertiesClone.get(storedIndex));
                selectedPropertiesClone.remove(storedIndex);
            }
        }
    }

    /**
     * Calculates the average price of a selected property
     */
    void calculatePriceAverage() {
        priceAverage = 0;
        int max = 0;
        for (AirbnbListing listing : selectedProperties) {
            max+= listing.getPrice();
        }
        priceAverage = max/selectedProperties.size();
    }

    /**
     * Calculates the average year availability for each selected property
     */
    void calculateAvailabilityAverage() {
        availabilityAverage = 0;
        int max = 0;
        for(AirbnbListing listing : selectedProperties) {
            max+= listing.getAvailability365();
        }
        availabilityAverage = max/selectedProperties.size();
    }

    /**
     * Calculates the average number of reviews for each property
     */
    void calculateReviewAverage() {
        reviewAverage = 0;
        int max = 0;
        for(AirbnbListing listing : selectedProperties) {
            max+= listing.getNumberOfReviews();
        }
        reviewAverage = max/selectedProperties.size();
    }

    /**
     * Calculates the average number of host listings for each selected property
     */
    void calculateHostListingsAverage() {
        hostListingsAverage = 0;
        int max = 0;
        for(AirbnbListing listing : selectedProperties) {
            max+= listing.getCalculatedHostListingsCount();
        }
        hostListingsAverage = max/selectedProperties.size();
    }

    /**
     * Calculates the average minimum nights stay for each selected property
     */
    void calculateMinimumNightsAverage() {
        minimumNightsAverage = 0;
        int max = 0;
        for(AirbnbListing listing : selectedProperties) {
            max+= listing.getMinimumNights();
        }
        minimumNightsAverage = max/selectedProperties.size();
    }

    /**
     * Gives a number of points to each property based on their price compared to the average property price.
     * The cheaper they are, the more points they get. It is the most influential condition for the recommendation algorithm.
     * @param pointsArray Array containing the points obtained by each property.
     */
     void givePricePoints(ArrayList<Integer> pointsArray) {
        for(int i=0; i<selectedProperties.size(); i++) {
            if(selectedProperties.get(i).getPrice() < 0.5*priceAverage) {
                pointsArray.set(i, pointsArray.get(i) + 420);
            }
            else if(selectedProperties.get(i).getPrice() < priceAverage) {
                pointsArray.set(i, pointsArray.get(i) + 200);
            }
        }
    }

    /**
     * Gives a number of points to each property based on their availability compared to the average.
     * The more days they are available, the more points they get. It is the second most influential condition.
     * @param pointsArray Array containing the points obtained by each property.
     */
    void giveAvailabilityPoints(ArrayList<Integer> pointsArray) {
        for(int i= 0; i<selectedProperties.size(); i++) {
            if(selectedProperties.get(i).getAvailability365() > 1.5 * availabilityAverage) {
                pointsArray.set(i, pointsArray.get(i) + 300);
            }

            else if(selectedProperties.get(i).getAvailability365() > availabilityAverage) {
                pointsArray.set(i, pointsArray.get(i) + 100);
            }
        }
    }

    /**
     * Gives a number of points to each property based on number of reviews compared to the average. The more reviews
     * there are (not necessarily positive) the more the user can be informed about the property, so the more
     * points it will get.
     * @param pointsArray Array containing the points obtained by each property.
     */
    void giveReviewPoints(ArrayList<Integer> pointsArray) {
        for(int i= 0; i<selectedProperties.size(); i++) {
            if(selectedProperties.get(i).getNumberOfReviews() > 1.5 * reviewAverage) {
                pointsArray.set(i, pointsArray.get(i) + 200);
            }

            else if(selectedProperties.get(i).getNumberOfReviews() > reviewAverage) {
                pointsArray.set(i, pointsArray.get(i) + 75);
            }
        }

    }

    /**
     * Gives a number of points to each property based on the number of listings that property's host has on the website,
     * compared to the average. The more listings it has, the more the host can be considered reliable, so the more points
     * the property gets.
     * @param pointsArray Array containing the points obtained by each property.
     */
    void giveHostListingsPoints(ArrayList<Integer> pointsArray) {
        for (int i = 0; i < selectedProperties.size(); i++) {
            if (selectedProperties.get(i).getCalculatedHostListingsCount() > 1.5 * hostListingsAverage) {
                pointsArray.set(i, pointsArray.get(i) + 200);
            }

            else if (selectedProperties.get(i).getCalculatedHostListingsCount() > hostListingsAverage) {
                pointsArray.set(i, pointsArray.get(i) + 75);
            }
        }
    }

    /**
     * Gives a number of points to each property based on the minimum number of nights someone needs to stay, compared
     * to the average. The fewer nights the customer has to stay, the more flexibility they have towards planning their
     * journey, and the more points the property gets.
     * @param pointsArray Array containing the points obtained by each property.
     */
    void giveMinimumNightsPoints(ArrayList<Integer> pointsArray) {
        for(int i= 0; i<selectedProperties.size(); i++) {
            if (selectedProperties.get(i).getMinimumNights() < 0.5 * minimumNightsAverage) {
                pointsArray.set(i, pointsArray.get(i) + 250);
            } else if (selectedProperties.get(i).getMinimumNights() < minimumNightsAverage) {
                pointsArray.set(i, pointsArray.get(i) + 100);
            }
        }
    }

    /**
     * Accessor method created for testing.
     * @return list of selected properties.
     */
    public List<AirbnbListing> getSelectedProperties() {
        return selectedProperties;
    }

    /**
     * Accessor method created for testing.
     * @return Average price.
     */
    public float getPriceAverage() {
        return priceAverage;
    }

    /**
     * Accessor method created for testing.
     * @return Average availability.
     */
    public float getAvailabilityAverage() {
        return availabilityAverage;
    }

    /**
     * Accessor method created for testing.
     * @return Average review.
     */
    public float getReviewAverage() {
        return reviewAverage;
    }

    /**
     * Accessor method created for testing.
     * @return Average host listings.
     */
    public float getHostListingsAverage() {
        return hostListingsAverage;
    }

    /**
     * Accessor method created for testing.
     * @return Average minimum nights.
     */
    public float getMinimumNightsAverage() {
        return minimumNightsAverage;
    }
}

import java.util.ArrayList;
import java.util.List;

/**
 * A class to deal with the statistics algorithms.
 * Provides the method to calculate the 4 given statistics,
 * plus the optional ones.
 *
 * @author Alfredo Musumeci, Pratibha Jain.
 * @version 29/03/2020
 */
public class Statistics {
    // List of listings.
    private List<AirbnbListing> listings;
    // Used to filter the listings.
    private PropertiesLoader properties;
    // List of neighbourhoods.
    private ArrayList<String> neighbourhoods;

    /**
     * Constructor for class statistics.
     * @param properties Filter and provider of properties.
     */
    public Statistics(PropertiesLoader properties) {
        this.properties = properties;
        listings = properties.getListings();
        neighbourhoods = new ArrayList<>(properties.loadNeighbourhood());
    }

    /**
     * Method to get the average number of reviews per property.
     * @return avgNumberOfReviews The average number of reviews per property.
     */
    public int getAverageNumberOfReviewsPerProperty() {
        int avgNumberOfReviews;
        int totalNumberOfReviews = 0;
        for (AirbnbListing listing : listings) {
            totalNumberOfReviews += listing.getNumberOfReviews();
        }
        avgNumberOfReviews = totalNumberOfReviews / listings.size();
        return avgNumberOfReviews;
    }

    /**
     * Method to return the total number of available properties.
     * The total number of available properties here is interpreted
     * as the properties that are available for at least 1 out of
     * 365 days of the year.
     * @return numberOfAvailableProperties The total number of properties
     * that are available for at least 1 day of a year.
     */
    public int getNumberOfAvailableProperties() {
        int numberOfAvailableProperties = 0;
        for (AirbnbListing listing : listings) {
            if (listing.getAvailability365() > 0) {
                numberOfAvailableProperties += 1;
            }
        }
        return numberOfAvailableProperties;
    }

    /**
     * Return the number of entire homes and apartments.
     * @return numberOfEntireHomesAndAparts The number of entire homes and apartments.
     */
    public int getNumberOfEntireHomesAndAparts() {
        int numberOfEntireHomesAndAparts = 0;
        for (AirbnbListing listing : listings) {
            if (listing.getRoom_type().equals("Entire home/apt")) {
                numberOfEntireHomesAndAparts += 1;
            }
        }
        return numberOfEntireHomesAndAparts;
    }

    /**
     * Return the most expensive borough among all boroughs.
     * @return mostExpBorough The most expensive borough.
     */
    public String getMostExpBorough() {
        ArrayList<AirbnbListing> propertiesInBorough;
        int index = -1;
        float mostExpBoroughPrice = 0;
        float price = 0;
        for (int i = 0; i < neighbourhoods.size(); i++) {
            propertiesInBorough = properties.loadPropertiesInBorough(neighbourhoods.get(i));
            for (AirbnbListing property : propertiesInBorough) {
                price += property.getPrice() * property.getMinimumNights();
            }
            if (price / propertiesInBorough.size() > mostExpBoroughPrice) {
                mostExpBoroughPrice = price / propertiesInBorough.size();
                index = i;
            }
            propertiesInBorough.clear();
        }
        if (index != -1) {
            return neighbourhoods.get(index);
        } else
            return null;
    }

    /**
     * Return the number of optimum properties.
     * Optimum properties are defined as those properties
     * whose price lies below the average price, and the number of
     * reviews lies above the average number of reviews.
     * It is assumed that all reviews are positive.
     * @return numberOfOptimumProperties The number of optimum properties based on this definition.
     */
    public int getNumberOfOptimumProperties() {
        int numberOfOptimumProperties = 0;

        float avgPrice = 0;
        float totalPrice = 0;

        float avgNumberOfReviews = 0;
        float totalNumberOfReviews = 0;
        for (AirbnbListing property : listings) {
            // Get the average price for the properties.
            totalPrice += property.getPrice();
            avgPrice = totalPrice / listings.size();

            // Get the average number of reviews.
            totalNumberOfReviews += property.getNumberOfReviews();
            avgNumberOfReviews = totalNumberOfReviews / listings.size();


            if (property.getPrice() < avgPrice &&
                    property.getNumberOfReviews() > avgNumberOfReviews) {
                numberOfOptimumProperties += 1;
            }
        }
        return numberOfOptimumProperties;
    }

    /**
     * Return the most popular property based on reviews per month.
     * It is assumed that the most popular property will be the one with
     * the maximum number of reviews per month.
     * @return String name of the most popular property.
     */
    public String getMostPopularProperty() {
        String mostPopularProperty = "";
        double MaxReviewsPerMonth = 0;
        for (AirbnbListing property : listings) {
            if (property.getReviewsPerMonth() > MaxReviewsPerMonth) {
                MaxReviewsPerMonth = property.getReviewsPerMonth();
                mostPopularProperty = property.getName();
            }
        }
        return mostPopularProperty;
    }

    /**
     * Return the most populated borough,
     * the borough with the maximum no. of properties.
     * @return The most populated borough.
     */
    public String getMostPopulatedBorough() {
        ArrayList<AirbnbListing> propertiesInBorough;
        int index = -1;
        float noPropertiesInBorough;
        float maxNoProperties = 0;

        for (int i = 0; i < neighbourhoods.size(); i++) {
            propertiesInBorough = properties.loadPropertiesInBorough(neighbourhoods.get(i));
            noPropertiesInBorough = propertiesInBorough.size();
            if (noPropertiesInBorough > maxNoProperties) {
                maxNoProperties = noPropertiesInBorough;
                index = i;
            }
            propertiesInBorough.clear();
        }
        if (index != -1) {
            return neighbourhoods.get(index);
        } else
            return null;
    }

    /**
     * Return the cheapest property, whose room is private.
     * @return The cheapest property with private room.
     */
    public String getCheapestPrivateRoom() {
        ArrayList<AirbnbListing> propertiesWithPrivateRoom = new ArrayList<>(properties.loadPropertiesRoomType("Private room"));
        // Random starting to price to be sure there will be cheaper properties.
        int lowestPrice = 100;
        int price;
        String cheapestProperty = "";
        String boroughProperty = "";

        for (AirbnbListing property : propertiesWithPrivateRoom) {
            price = property.getPrice();
            if (price < lowestPrice) {
                    lowestPrice = price;
                    cheapestProperty = property.getName();
                    boroughProperty = property.getNeighbourhood();
                }
            }
        return cheapestProperty + "\n Location: " + boroughProperty;
    }
}
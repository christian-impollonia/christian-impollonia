import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

/**
 * Class used to test the main methods of the Recommender class. So that every test is independent, the recommender
 * object to call the method is created inside each test. To test also, two test properties are created at the beginning,
 * which can be use as samples to assert test results.
 * All tests are called exactly like the method they are testing plus the "Test" word at the end.
 *
 * @author Christian Impollonia
 * @version 2020.03.27
 */

public class RecommenderTest {

AirbnbListing testListing1;
AirbnbListing testListing2;


    public RecommenderTest()
{
    testListing1 = new AirbnbListing(15, 27, 19, 23, 49);
    testListing2 = new AirbnbListing(24, 37, 62, 125, 71);
}

    @Test
    public void setPropertiesListTest() {
        Recommender recommender = new Recommender();
        List<AirbnbListing> properties = new ArrayList<>();
        recommender.setPropertiesList(properties);
        org.junit.Assert.assertEquals(recommender.getSelectedProperties(), properties);

    }

    @Test
   public void calculatePriceAverageTest() {
        Recommender recommender = new Recommender();
        List<AirbnbListing> properties = new ArrayList<>();
        recommender.setPropertiesList(properties);
        properties.add(testListing1);
        properties.add(testListing2);
        recommender.calculatePriceAverage();
        //Because with float numbers you can't be sure about total equality, the number was checked within a specific range
        org.junit.Assert.assertTrue(recommender.getPriceAverage()>=19 && recommender.getPriceAverage() <= 20 );

   }

    @Test
    public void calculateAvailabilityAverageTest() {
        Recommender recommender = new Recommender();
        List<AirbnbListing> properties = new ArrayList<>();
        recommender.setPropertiesList(properties);
        properties.add(testListing1);
        properties.add(testListing2);
        recommender.calculateAvailabilityAverage();
        //Because with float numbers you can't be sure about total equality, the number was checked within a specific range
        org.junit.Assert.assertTrue(recommender.getAvailabilityAverage()>=59.5 && recommender.getAvailabilityAverage()<=60.5);

    }

    @Test
    public void calculateReviewAverageTest() {
        Recommender recommender = new Recommender();
        List<AirbnbListing> properties = new ArrayList<>();
        recommender.setPropertiesList(properties);
        properties.add(testListing1);
        properties.add(testListing2);
        recommender.calculateReviewAverage();
        //Because with float numbers you can't be sure about total equality, the number was checked within a specific range
        org.junit.Assert.assertTrue(recommender.getReviewAverage() >= 40 && recommender.getReviewAverage() <= 41);

    }

    @Test
    public void calculateHostListingsAverageTest() {
        Recommender recommender = new Recommender();
        List<AirbnbListing> properties = new ArrayList<>();
        recommender.setPropertiesList(properties);
        properties.add(testListing1);
        properties.add(testListing2);
        recommender.calculateHostListingsAverage();
        //Because with float numbers you can't be sure about total equality, the number was checked within a specific range
        org.junit.Assert.assertTrue(recommender.getHostListingsAverage() >= 73.5 && recommender.getHostListingsAverage() <= 74.5);

    }

    @Test
    public void calculateMinimumNightsAverageTest() {
        Recommender recommender = new Recommender();
        List<AirbnbListing> properties = new ArrayList<>();
        recommender.setPropertiesList(properties);
        properties.add(testListing1);
        properties.add(testListing2);
        recommender.calculateMinimumNightsAverage();
        //Because with float numbers you can't be sure about total equality, the number was checked within a specific range
        org.junit.Assert.assertTrue(recommender.getMinimumNightsAverage() >= 31.5 && recommender.getMinimumNightsAverage() <= 32.5);

    }

    @Test
    public void givePricePointsTest() {
       Recommender recommender = new Recommender();
       List<AirbnbListing> properties = new ArrayList<>();
       ArrayList<Integer> pointsArray = new ArrayList<>();
       recommender.setPropertiesList(properties);
        properties.add(testListing1);
        properties.add(testListing2);
        recommender.calculatePriceAverage();
       for(AirbnbListing listing : properties)
       {
           pointsArray.add(0);
       }
       recommender.givePricePoints(pointsArray);
       org.junit.Assert.assertTrue(pointsArray.get(0) == 200);
       org.junit.Assert.assertTrue(pointsArray.get(1) == 0);

    }

    @Test
    public void giveAvailabilityPointsTest() {
        Recommender recommender = new Recommender();
        List<AirbnbListing> properties = new ArrayList<>();
        ArrayList<Integer> pointsArray = new ArrayList<>();
        recommender.setPropertiesList(properties);
        properties.add(testListing1);
        properties.add(testListing2);
        recommender.calculateAvailabilityAverage();
        for(AirbnbListing listing : properties)
        {
            pointsArray.add(0);
        }
        recommender.giveAvailabilityPoints(pointsArray);
        org.junit.Assert.assertTrue(pointsArray.get(0) == 0);
        org.junit.Assert.assertTrue(pointsArray.get(1) == 100);

    }

    @Test
    public void giveReviewPointsTest() {
        Recommender recommender = new Recommender();
        List<AirbnbListing> properties = new ArrayList<>();
        ArrayList<Integer> pointsArray = new ArrayList<>();
        recommender.setPropertiesList(properties);
        properties.add(testListing1);
        properties.add(testListing2);
        recommender.calculateReviewAverage();
        for(AirbnbListing listing : properties)
        {
            pointsArray.add(0);
        }
        recommender.giveReviewPoints(pointsArray);
        org.junit.Assert.assertTrue(pointsArray.get(0) == 0);
        org.junit.Assert.assertTrue(pointsArray.get(1) == 200);

    }

    @Test
    public void giveHostListingsPointsTest() {
        Recommender recommender = new Recommender();
        List<AirbnbListing> properties = new ArrayList<>();
        ArrayList<Integer> pointsArray = new ArrayList<>();
        recommender.setPropertiesList(properties);
        properties.add(testListing1);
        properties.add(testListing2);
        recommender.calculateHostListingsAverage();
        for(AirbnbListing listing : properties)
        {
            pointsArray.add(0);
        }
        recommender.giveHostListingsPoints(pointsArray);
        org.junit.Assert.assertTrue(pointsArray.get(0) == 0);
        org.junit.Assert.assertTrue(pointsArray.get(1) == 200);

    }

    @Test
    public void giveMinimumNightsPointsTest() {
        Recommender recommender = new Recommender();
        List<AirbnbListing> properties = new ArrayList<>();
        ArrayList<Integer> pointsArray = new ArrayList<>();
        recommender.setPropertiesList(properties);
        properties.add(testListing1);
        properties.add(testListing2);
        recommender.calculateMinimumNightsAverage();
        for(AirbnbListing ignored : properties)
        {
            pointsArray.add(0);
        }
        recommender.giveMinimumNightsPoints(pointsArray);
        org.junit.Assert.assertTrue(pointsArray.get(0) == 100);
        org.junit.Assert.assertTrue(pointsArray.get(1) == 0);

    }







    }
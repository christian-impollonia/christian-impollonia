import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.event.ActionEvent;
import javafx.scene.control.Button;

import java.io.IOException;

/**
 * This class manages the recommendedProperties pane and
 * all the action events that come with it.
 *
 * @author Christian Impollonia
 * @version 2020.03.26
 */
public class RecommenderController {
    // The labels for the five properties showed.
    @FXML
    private Label property1;
    @FXML
    private Label property2;
    @FXML
    private Label property3;
    @FXML
    private Label property4;
    @FXML
    private Label property5;

    // The buttons next to the names of the properties,
    // to view the property in more detail on the browser.
    @FXML
    private Button propertyButton1;
    @FXML
    private Button propertyButton2;
    @FXML
    private Button propertyButton3;
    @FXML
    private Button propertyButton4;
    @FXML
    private Button propertyButton5;

    // The recommender field that stores the Recommender object,
    // that handles the calculation of the recommendation.
    private Recommender recommender;

    /**
     * Updates the labels in the recommended properties' pane with the calculated results.
     * Buttons are originally invisible, they appear only if they have an associated property.
     * The labels and buttons are reset every time the method is called, to allow
     * for the possibility of less than 5 properties in a list.
     * @param event ActionEvent caused by clicking the recommend button at the bottom of the page.
     */
    @FXML
    public void showRecommendedProperties(ActionEvent event) {
        disableButtons();
        clearLabels();

        recommender.calculateProperties();
        if(recommender.getCalculatedProperties().size() >= 1) {
            property1.setText("1. " + recommender.getCalculatedProperties().get(0).getName());
            propertyButton1.setVisible(true);


            if (recommender.getCalculatedProperties().size() >= 2) {
                property2.setText("2. " + recommender.getCalculatedProperties().get(1).getName());
                propertyButton2.setVisible(true);


                if (recommender.getCalculatedProperties().size() >= 3) {
                    property3.setText("3. " + recommender.getCalculatedProperties().get(2).getName());
                    propertyButton3.setVisible(true);


                    if (recommender.getCalculatedProperties().size() >= 4) {
                        property4.setText("4. " + recommender.getCalculatedProperties().get(3).getName());
                        propertyButton4.setVisible(true);


                        if (recommender.getCalculatedProperties().size() == 5) {
                            property5.setText("5. " + recommender.getCalculatedProperties().get(4).getName());
                            propertyButton5.setVisible(true);
                        }
                    }
                }
            }
        }
    }

    /**
     * Gets the recommender from the GUI Controller,
     * to use it to calculate the recommended properties.
     * @param recommender Recommender to calculate the recommened properties.
     */
    public void setRecommender(Recommender recommender) {
        this.recommender = recommender;
    }


    /**
     * The methods below show the selected properties on google maps. The default browser is started. It can start with
     * a window at minimum size, in case it can only be adjusted by the user. They are called when the button of the
     * respective property is clicked.
     * @param event Button triggering the event.
     * @throws IOException
     */
    @FXML
    public void viewProperty1(ActionEvent event) throws IOException {
        String url = "https://www.google.com/maps/search/?api=1&query=" +
                recommender.getCalculatedProperties().get(0).getLatitude() +
                "," + recommender.getCalculatedProperties().get(0).getLongitude();

        java.awt.Desktop.getDesktop().browse(java.net.URI.create(url));
    }

    @FXML
    public void viewProperty2(ActionEvent event) throws IOException {
        String url = "https://www.google.com/maps/search/?api=1&query=" +
                recommender.getCalculatedProperties().get(1).getLatitude() +  "," +
                recommender.getCalculatedProperties().get(1).getLongitude();

        java.awt.Desktop.getDesktop().browse(java.net.URI.create(url));

    }

    @FXML
    public void viewProperty3(ActionEvent event) throws IOException {
        String url = "https://www.google.com/maps/search/?api=1&query=" +
                recommender.getCalculatedProperties().get(2).getLatitude() +
                "," + recommender.getCalculatedProperties().get(2).getLongitude();

        java.awt.Desktop.getDesktop().browse(java.net.URI.create(url));

    }

    @FXML
    public void viewProperty4(ActionEvent event) throws IOException {
        String url = "https://www.google.com/maps/search/?api=1&query=" +
                recommender.getCalculatedProperties().get(3).getLatitude() +
                "," + recommender.getCalculatedProperties().get(3).getLongitude();

        java.awt.Desktop.getDesktop().browse(java.net.URI.create(url));

    }

    @FXML
    public void viewProperty5(ActionEvent event) throws IOException {
        String url = "https://www.google.com/maps/search/?api=1&query=" +
                recommender.getCalculatedProperties().get(4).getLatitude()
                +  "," + recommender.getCalculatedProperties().get(4).getLongitude();

        java.awt.Desktop.getDesktop().browse(java.net.URI.create(url));
    }

    /**
     * Sets all the buttons to invisible to start fresh.
     */
   private void disableButtons() {
       propertyButton1.setVisible(false);
       propertyButton2.setVisible(false);
       propertyButton3.setVisible(false);
       propertyButton4.setVisible(false);
       propertyButton5.setVisible(false);
   }

    /**
     * Sets all the labels to their original text to start fresh.
     */
   private void clearLabels() {
       property1.setText("1. ");
       property2.setText("2. ");
       property3.setText("3. ");
       property4.setText("4. ");
       property5.setText("5. ");

   }
}


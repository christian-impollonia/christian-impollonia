import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

/**
 * The main application.
 * Create the graphical interface from an FXML file.
 *
 * @author Alfredo Musumeci, Christian Impollonia, Pratibha Jain.
 * @version 2020/03/12
 */
public class PropertyGUI extends Application {

    /**
     * Launch an instance of the application.
     */
    public static void main(String[] args) {
        launch(args);
    }

    /**
     * Make up the graphical interface.
     * @param primaryStage The main stage of the app.
     */
    @Override
    public void start(Stage primaryStage) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("main.fxml"));
            Parent root = loader.load();

            GUIController controller = loader.getController();
            controller.populateComboBox();
            controller.showWelcomePane();

            Scene scene = new Scene(root);

            primaryStage.setTitle("Property viewer");
            primaryStage.setScene(scene);
            primaryStage.show();
            primaryStage.setMinWidth(primaryStage.getWidth());
            primaryStage.setMinHeight(primaryStage.getHeight());
        }
        catch(IOException e) {
            e.printStackTrace();
            System.out.print("There was a problem loading one of the FXML files");
        }
    }
}
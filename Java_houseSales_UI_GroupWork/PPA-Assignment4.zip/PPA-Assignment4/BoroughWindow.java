import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

import java.io.IOException;

/**
 * A class to deal with the BoroughWindow.
 * It provides the view of the pane, in other words
 * it can be considered the GUI for the BoroughWindow.
 * i.e. The list of viewable properties is defined here,
 * and then added to the pane.
 *
 * @author Alfredo Musumeci
 * @version 2020/03/14
 */
public class BoroughWindow {
    // Pane to be showed when a borough is clicked.
    private Pane boroughPane;
    // A viewable interface for list of properties.
    private Stage stage;
    private Scene scene;
    // A list containing properties of a given borough.
    private ObservableList<AirbnbListing> properties;
    private BoroughController controllerBorough;

    /**
     * Constructor for class BoroughWindow.
     * Set up the scene.
     */
    public BoroughWindow(){
        // Set the window to be used later to show the properties per borough.
        stage = new Stage();

        properties = FXCollections.observableArrayList();
    }

    /**
     * Create the BoroughGUI window.
     */
    public void setUpWindow(ObservableList<AirbnbListing> propertiesToShow) {
        try {
            // Load the fxml file containing the borough window.
            FXMLLoader loaderBoroughWindow = new FXMLLoader(getClass().getResource("boroughWindow.fxml"));
            boroughPane = loaderBoroughWindow.load();

            controllerBorough = loaderBoroughWindow.getController();
            controllerBorough.showProperties(propertiesToShow);
            controllerBorough.populateSortBy();

            // Set the scene.
            scene = new Scene(boroughPane);
        }
        catch (IOException e) {
            e.printStackTrace();
            System.out.print("There was a problem loading the FXML file");
        }
    }

    /**
     * Create a window with a specific boroughName.
     * @param boroughName Name of the corresponding borough.
     * @param boroughWindow to contain the properties in a borough.
     */
    public void showWindow(String boroughName, Pane boroughWindow)
    {
        stage.setTitle(boroughName);
        stage.setScene(scene);
        stage.show();
        stage.setMinHeight(boroughWindow.getHeight());
        stage.setMinWidth(boroughWindow.getWidth());
    }

    /**
     * Return the list of observable properties.
     * @return The list of observable properties.
     */
    public ObservableList<AirbnbListing> getProperties() {
        return properties;
    }

    /**
     * Return the pane being created by the fxml file.
     * @return The borough pane created by the fxml file.
     */
    public Pane getBoroughPane(){
        return boroughPane;
    }
}

import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

import java.io.IOException;

/**
 * A simple controller for the borough window.
 * It provides the logic for the elements inside the borough pane.
 *
 * @author Alfredo Musumeci
 * @version 2020/03/14
 */
public class BoroughController {
    // Pane to be showed when a borough is clicked.
    private Pane propertyInfo;
    // A viewable interface for properties' information.
    private Stage stage;
    private Scene scene;
    // Controller to have access to the property pane.
    private PropertyInfoController infoController;

    // Combobox to store the options for sorting by.
    @FXML
    private ComboBox sortBy;
    // TableView to store the list of properties.
    @FXML
    private TableView<AirbnbListing> viewableProperties;
    // Columns for the TableView.
    @FXML
    private TableColumn<AirbnbListing, String> nameCol;
    @FXML
    private TableColumn<AirbnbListing, String> hostCol;
    @FXML
    private TableColumn<AirbnbListing, String> priceCol;
    @FXML
    private TableColumn<AirbnbListing, String> noReviewsCol;
    @FXML
    private TableColumn<AirbnbListing, String> noMinNightsCol;

    /**
     * Constructor for class BoroughController.
     */
    public BoroughController() {
        // Set the window to be used later to show the properties' info.
        stage = new Stage();
    }

    /**
     * Executed after the constructor, when the FXML files
     * are injected. Make the TableRows clickable.
     * On click, a new window with the property
     * information is displayed.
     */
    public void initialize() {
        viewableProperties.setRowFactory(tv -> {
            TableRow<AirbnbListing> row = new TableRow<>();
            row.setOnMouseClicked(event -> {
                if ((event.getClickCount() == 2) && (!row.isEmpty())) {
                    if(event.getButton() == MouseButton.PRIMARY) {
                        loadInfoPane(row.getItem().getName());
                        infoController.loadPropertyInfo(row.getItem());
                    }
                }
            });
            return row;
        });
    }

    /**
     * Create a window with specific property information.
     */
    public void loadInfoPane(String title) {
        try {
            // Load the fxml file containing the properties' info.
            FXMLLoader loaderInfoWindow = new FXMLLoader(getClass().getResource("propertyWindow.fxml"));
            propertyInfo = loaderInfoWindow.load();
            infoController = loaderInfoWindow.getController();

            // Set the scene.
            scene = new Scene(propertyInfo);
            stage.setTitle(title);
            stage.setScene(scene);
            stage.show();
            stage.setMinHeight(propertyInfo.getHeight());
            stage.setMinWidth(propertyInfo.getWidth());

        }
        catch (IOException e) {
            e.printStackTrace();
            System.out.print("There was a problem loading the FXML file");
        }
    }

    /**
     * Fill the TableView columns with the
     * appropriate information.
     * @param properties list of properties the user can see.
     */
    public void showProperties(ObservableList<AirbnbListing> properties) {
        viewableProperties.setItems(properties);
        // The name of the PropertyValueFactory must match the respective
        // getMethod in the Model class, i.e. getName in AirbnbListing.
        nameCol.setCellValueFactory(new PropertyValueFactory("name"));
        hostCol.setCellValueFactory(new PropertyValueFactory("host_name"));
        priceCol.setCellValueFactory(new PropertyValueFactory("price"));
        noReviewsCol.setCellValueFactory(new PropertyValueFactory("numberOfReviews"));
        noMinNightsCol.setCellValueFactory(new PropertyValueFactory("minimumNights"));
        viewableProperties.getColumns().setAll(nameCol, hostCol, priceCol, noReviewsCol, noMinNightsCol);
    }

    /**
     * Populate the ComboBox sortBy using an apposite class.
     */
    public void populateSortBy() {
        sortBy.getItems().addAll(new SortByOption("Number of reviews", noReviewsCol),
                                new SortByOption("Price", priceCol),
                                new SortByOption("Host name", hostCol));
    }

    /**
     * Sort the list of available properties by the
     * apposite options in the ComboBox menu.
     */
    @FXML
    private void sortBy(ActionEvent event) {
        // Get the name of the column to sort by.
        TableColumn<AirbnbListing, String> option =
                ((SortByOption) sortBy.getSelectionModel().getSelectedItem()).getColumnName();

        option.setSortable(true);
        viewableProperties.getSortOrder().add(option);
        option.setSortable(false);
    }
}
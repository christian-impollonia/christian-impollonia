import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.Alert.*;
import javafx.scene.layout.GridPane;

/**
 * A simple controller for the property-info pane.
 * It provides the logic for the elements inside the pane.
 *
 * @author Alfredo Musumeci
 * @version 2020/03/25
 */
public class PropertyInfoController {
    // Labels with the property information.
    @FXML
    private Label propertyIDLabel;
    @FXML
    private Label nameLabel;
    @FXML
    private Label hostIDLabel;
    @FXML
    private Label hostNameLabel;
    @FXML
    private Label neighbourhoodLabel;
    @FXML
    private Label roomTypeLabel;
    @FXML
    private Label priceLabel;
    @FXML
    private Label minNightsLabel;
    @FXML
    private Label noReviewsLabel;
    @FXML
    private Label lastReviewLabel;
    @FXML
    private Label reviewsPerMonthLabel;
    @FXML
    private Label calcHostListingsCountLabel;
    @FXML
    private Label availabilityLabel;
    // TextArea for location URL.
    private TextArea mapsURL;

    /**
     * Constructor for class PropertyInfoController.
     */
    public PropertyInfoController() {
        mapsURL = new TextArea();
        mapsURL.setEditable(false);
        mapsURL.setWrapText(true);
    }

    /**
     * Load the information for the relevant property.
     */
    public void loadPropertyInfo(AirbnbListing property) {
        propertyIDLabel.setText("Current property ID is: " + property.getId());
        nameLabel.setText(property.getName());
        hostIDLabel.setText(property.getHost_id());
        hostNameLabel.setText(property.getHost_name());
        neighbourhoodLabel.setText(property.getNeighbourhood());
        roomTypeLabel.setText(property.getRoom_type());
        priceLabel.setText("£" + property.getPrice());
        minNightsLabel.setText("" + property.getMinimumNights());
        noReviewsLabel.setText("" + property.getNumberOfReviews());
        lastReviewLabel.setText(property.getLastReview());
        reviewsPerMonthLabel.setText("" + property.getReviewsPerMonth());
        calcHostListingsCountLabel.setText("" + property.getCalculatedHostListingsCount());
        availabilityLabel.setText(property.getAvailability365() + "/365");
        mapsURL.setText("Copy and paste this link to your browser to see the location!\n" +
                "https://www.google.com/maps/place/" + property.getLatitude() + "," + property.getLongitude());
    }

    /**
     * Display an information alert containing the URL
     * of the location on a click of the given button.
     */
    @FXML
    private void seeOnMap(ActionEvent event) {
        GridPane gridPane = new GridPane();
        gridPane.add(mapsURL, 0, 0);

        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle("Location");
        alert.setHeaderText(null);
        alert.getDialogPane().setContent(gridPane);
        alert.showAndWait();
    }
}

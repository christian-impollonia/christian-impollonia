import java.util.*;

/**
 * A class to manipulate the properties from the data set.
 * It allows to filter the properties on specific constraints.
 *
 * @author Alfredo Musumeci
 * @version 2020/03/12
 */
public class PropertiesLoader {
    AirbnbDataLoader propertiesLoader;
    // Minimum value of property price.
    private int selectedMinValue;
    // Maximum value of property price.
    private int selectedMaxValue;

    /**
     * Constructor for class PropertiesLoader.
     * Load the data set and initialize the min/max values.
     */
    public PropertiesLoader() {
        propertiesLoader = new AirbnbDataLoader();
        // Price range is not set yet.
        selectedMinValue = 0;
        selectedMaxValue = 0;
    }

    /**
     * Return a list of all the properties' price,
     * duplicates are eliminated.
     * @return (Tree)Set of properties' price.
     */
    public Set<Integer> loadPrices() {
        Set<Integer> prices = new TreeSet<>();
        for (AirbnbListing property : propertiesLoader.getListings()) {
            prices.add(property.getPrice());
        }
        return prices;
    }

    /**
     * Return a list of all neighbourhoods,
     * duplicates are eliminated.
     * @return (Hash)Set of neighbourhoods.
     */
    public Set<String> loadNeighbourhood() {
        Set<String> neighbourhoods = new HashSet<>();
        for (AirbnbListing property : propertiesLoader.getListings()) {
            neighbourhoods.add(property.getNeighbourhood());
        }
        return neighbourhoods;
    }

    /**
     * Filter the list of properties on the neighbourhood.
     * @param neighbourhood The neighbourhood to sort on.
     * @return A list of properties in that neighbourhood.
     */
    public ArrayList<AirbnbListing> loadPropertiesInBorough(String neighbourhood) {
        ArrayList<AirbnbListing> properties = new ArrayList<>();
        for (AirbnbListing property: propertiesLoader.getListings()) {
            if (property.getNeighbourhood().equals(neighbourhood)) {
                properties.add(property);
            }
        }
        return properties;
    }

    /**
     * Filter the list of properties on the room type.
     * @param roomType The room type to sort on.
     * @return A list of properties with that room type.
     */
    public ArrayList<AirbnbListing> loadPropertiesRoomType(String roomType) {
        ArrayList<AirbnbListing> properties = new ArrayList<>();
        for (AirbnbListing property: propertiesLoader.getListings()) {
            if (property.getRoom_type().equals(roomType)) {
                properties.add(property);
            }
        }
        return properties;
    }

    /**
     * Return the whole list of properties.
     * @return List of properties.
     */
    public List<AirbnbListing> getListings() {
        return propertiesLoader.getListings();
    }

    /**
     * Return the selected min value.
     * @return The min value.
     */
    public int getSelectedMinValue() {
        return selectedMinValue;
    }

    /**
     * Return the selected max value.
     * @return The max value.
     */
    public int getSelectedMaxValue() {
        return selectedMaxValue;
    }

    /**
     * Set a "selected" min value.
     * @param minValue Minimum value.
     */
    public void selectMinValue(int minValue) {
        selectedMinValue = minValue;
    }

    /**
     * Set a "selected" max value.
     * @param maxValue Maximum value.
     */
    public void selectMaxValue(int maxValue) {
        selectedMaxValue = maxValue;
    }
}
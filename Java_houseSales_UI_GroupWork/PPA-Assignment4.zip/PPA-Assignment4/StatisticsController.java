import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.TextAlignment;

import java.util.ArrayList;

/**
 * A simple controller for the statistics pane.
 * It provides the logic for the elements inside the pane.
 *
 * @author Alfredo Musumeci, Pratibha Jain.
 * @version 2020/03/29
 */
public class StatisticsController {
    // Statistics boxes to contain the statistics results.
    @FXML
    private BorderPane statisticsBox1;
    @FXML
    private BorderPane statisticsBox2;
    @FXML
    private BorderPane statisticsBox3;
    @FXML
    private BorderPane statisticsBox4;

    // List of statistics on screen.
    private ArrayList<VBox> statisticsOnScreen;
    // List of statistics that are not on screen.
    private ArrayList<VBox> statisticsNotOnScreen;
    // Statistics results provider.
    private Statistics statisticsInfo;

    /**
     * Constructor for class StatisticsController.
     */
    public StatisticsController() {
        statisticsOnScreen = new ArrayList<>();
        statisticsNotOnScreen = new ArrayList<>();
    }

    /**
     * Create the statisticsInfo, populate the screen with statistics
     * and set the two lists accordingly.
     * @param properties Filter and provider of properties.
     */
    public void initialize(PropertiesLoader properties) {
        statisticsInfo = new Statistics(properties);
        populateStatistics();
        populateStatisticsNotOnScreen();
        setDefaultStatisticsBox();
    }

    /**
     * Set the statistics boxes to contain some default results.
     */
    private void setDefaultStatisticsBox() {
        statisticsBox1.setCenter(statisticsOnScreen.get(0));
        statisticsBox2.setCenter(statisticsOnScreen.get(1));
        statisticsBox3.setCenter(statisticsOnScreen.get(2));
        statisticsBox4.setCenter(statisticsOnScreen.get(3));
    }

    /**
     * Populate the statisticsOnScreen list.
     */
    private void populateStatistics() {
        statisticsOnScreen.add(createStatisticsBox("Average number of reviews per property",
                Integer.toString(statisticsInfo.getAverageNumberOfReviewsPerProperty())));
        statisticsOnScreen.add(createStatisticsBox("Total number of available properties",
                Integer.toString(statisticsInfo.getNumberOfAvailableProperties())));
        statisticsOnScreen.add(createStatisticsBox("Number of entire home and apartments",
                Integer.toString(statisticsInfo.getNumberOfEntireHomesAndAparts())));
        statisticsOnScreen.add(createStatisticsBox("The most expensive borough",
                statisticsInfo.getMostExpBorough()));
    }

    /**
     * Populate the statistics not on screen list.
     */
    private void populateStatisticsNotOnScreen() {
        statisticsNotOnScreen.add(createStatisticsBox("Number of optimum properties, that is, below average price" +
                " and over average reviews", Integer.toString(statisticsInfo.getNumberOfOptimumProperties())));
        statisticsNotOnScreen.add(createStatisticsBox("Most popular property",
                statisticsInfo.getMostPopularProperty()));
        statisticsNotOnScreen.add(createStatisticsBox("Most popular borough",
                statisticsInfo.getMostPopulatedBorough()));
        statisticsNotOnScreen.add(createStatisticsBox("Cheapest private room",
                statisticsInfo.getCheapestPrivateRoom()));
    }

    /**
     * Create the VBoxes to contain the stats' info.
     * @param statisticsName The name of the statistics.
     * @param statisticsResult The result of the statistics.
     * @return A VBox containing the stats' info.
     */
    public VBox createStatisticsBox(String statisticsName, String statisticsResult) {
        VBox statistics = new VBox();
        Label statisticsLabel = new Label();
        Label resultLabel = new Label();

        statisticsLabel.setText(statisticsName);
        resultLabel.setText(statisticsResult);
        statisticsLabel.setFont(new Font(20));
        resultLabel.setFont(new Font(20));

        statisticsLabel.setTextAlignment(TextAlignment.CENTER);
        statisticsLabel.translateXProperty().bind(statistics.widthProperty().subtract(statisticsLabel.widthProperty()).divide(2));
        statisticsLabel.translateYProperty().bind(statistics.heightProperty().subtract(statisticsLabel.heightProperty()).divide(4));
        resultLabel.translateXProperty().bind(statistics.widthProperty().subtract(resultLabel.widthProperty()).divide(2));
        resultLabel.translateYProperty().bind(statistics.heightProperty().subtract(resultLabel.heightProperty()).divide(2));
        statisticsLabel.setWrapText(true);

        statistics.getChildren().addAll(statisticsLabel, resultLabel);
        statistics.setPadding(new Insets(0,5,0,5));

        return statistics;
    }

    /**
     * Used by both previous and next buttons.
     * Generate a random following statistics, checking if it is
     * not already on screen.
     * @param event Button triggering the action.
     */
    @FXML
    public void nextBox(ActionEvent event) {
        Button buttonPressed = (Button) event.getSource();
        BorderPane pane = (BorderPane) buttonPressed.getParent();
        statisticsNotOnScreen.add((VBox) pane.getCenter());
        statisticsOnScreen.remove(pane.getCenter());
        pane.setCenter(null);
        addInScreen(pane, statisticsNotOnScreen.get(0));
    }

    /**
     * Add the statistics to the statisticsBox.
     * @param statisticsBox The pane where to add the VBox containing the stats' info.
     * @param statistics The given VBox containing the statistics.
     */
    private void addInScreen(BorderPane statisticsBox, VBox statistics) {
        statisticsBox.setCenter(statistics);
        statisticsOnScreen.add(statistics);
        statisticsNotOnScreen.remove(statistics);
    }
}

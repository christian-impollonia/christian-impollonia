import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.*;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.Region;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * A simple controller for the GUI.
 * Provide the logic for the main pane, have
 * access to the controllers of the other panes.
 *
 * @author Alfredo Musumeci, Christian Impollonia
 * @version 2020/03/12
 */
public class GUIController {
    // Container for all the panes to be displayed.
    @FXML
    private Pane containerPane;
    // All panes that will be displayed inside the containerPane.
    private Pane welcomePane;
    private Pane mapPane;
    private Pane statisticsPane;
    private Pane recommendedPropertiesPane;
    // Combo boxes for the prices.
    @FXML
    private ComboBox from, to;
    // Buttons to move between panes.
    @FXML
    private Button next, previous;
    // Controllers to get the methods from the other panes.
    private WelcomePaneController controllerWelcome;
    private MapController controllerMap;
    private StatisticsController controllerStats;
    private RecommenderController controllerRecommend;
    // List of panes available.
    private static List<Pane> panes = new ArrayList<>();
    // Index of the currentPane.
    private int currentPane;

    ArrayList<AirbnbListing> selectedListings = new ArrayList<>();
    private PropertiesLoader properties;
    private Recommender recommender;


    /**
     * Constructor for class GUIController.
     * Load the FXML files to be viewed when moving between panes,
     * load the properties onto the system, set the current pane.
     **/
    public GUIController(){
        try {
            FXMLLoader loaderWelcome = new FXMLLoader(getClass().getResource("welcome.fxml"));
            welcomePane = loaderWelcome.load();
            controllerWelcome = loaderWelcome.getController();

            FXMLLoader loaderMap = new FXMLLoader(getClass().getResource("mapWindow.fxml"));
            mapPane = loaderMap.load();
            controllerMap = loaderMap.getController();

            FXMLLoader loaderStats = new FXMLLoader(getClass().getResource("statistics.fxml"));
            statisticsPane = loaderStats.load();
            controllerStats = loaderStats.getController();

            properties = new PropertiesLoader();
            controllerStats.initialize(properties);

            FXMLLoader loaderRecommend = new FXMLLoader(getClass().getResource("recommendedProperties.fxml"));
            recommendedPropertiesPane = loaderRecommend.load();
            controllerRecommend = loaderRecommend.getController();
        }
        catch (IOException e) {
            e.printStackTrace();
            System.out.print("There was a problem loading one of the FXML files");
        }

        recommender = new Recommender();
        recommender.setPropertiesList(selectedListings);
        controllerRecommend.setRecommender(recommender);


        currentPane = 0;
        // Add all panes to the list of panes.
        addPanes();
    }

    /**
     * Executed after the FXML files are injected,
     * make sure the window are bound to the main fxml file.
     */
    public void initialize() {
        containerPane.setPrefWidth(800);
        containerPane.setPrefHeight(400);
        for(Pane pane : panes) {
            pane.minWidthProperty().bind(containerPane.widthProperty());
            pane.maxWidthProperty().bind(containerPane.widthProperty());
            pane.minHeightProperty().bind(containerPane.heightProperty());
            pane.maxHeightProperty().bind(containerPane.heightProperty());
        }
    }

    /**
     * Add the panes to the list of panes.
     */
    public void addPanes() {
        panes.add(welcomePane);
        panes.add(mapPane);
        panes.add(statisticsPane);
        panes.add(recommendedPropertiesPane);
    }

    /**
     * Populate the combobox with the prices
     * taken from the properties.
     */
    public void populateComboBox() {
        for (Object price : properties.loadPrices()) {
            from.getItems().add(price);
        }
        for (Object price : properties.loadPrices()) {
            to.getItems().add(price);
        }
    }

    /**
     * Show the welcome pane, that is, the pane welcoming
     * the user.
     */
    public void showWelcomePane(){
        containerPane.getChildren().add(panes.get(0));
    }

    /**
     * Move to the next pane.
     * @param event ">" button.
     */
    @FXML
    private void nextPane(ActionEvent event) {
        containerPane.getChildren().remove(panes.get(currentPane));
        if (currentPane == (panes.size() - 1)) {
            currentPane = 0;
        } else {
            currentPane++;
        }
        containerPane.getChildren().add(panes.get(currentPane));
    }

    /**
     * Move to the previous pane.
     * @param event "<" button.
     */
    @FXML
    private void previousPane(ActionEvent event) {
        containerPane.getChildren().remove(panes.get(currentPane));
        if (currentPane == 0) {
            currentPane = panes.size() - 1;
        } else {
            currentPane--;
        }
        containerPane.getChildren().add(panes.get(currentPane));
    }

    /**
     * Activate the "from" comboBox.
     * @param event "From" comboBox.
     */
    @FXML
    private void activateFrom(ActionEvent event) {
        // Choose a "from" value.
        properties.selectMinValue((int) from.getSelectionModel().getSelectedItem());
        check(to);
    }

    /**
     * Activate the "to" comboBox.
     * @param event "To" comboBox.
     */
    @FXML
    private void activateTo(ActionEvent event) {
        // Choose a "to" value.
        properties.selectMaxValue((int) to.getSelectionModel().getSelectedItem());
        check(from);
    }

    /**
     * Check if both comboBoxes have been activated with a
     * correct price range, else show an error.
     * Enable the buttons, and generate or update the map.
     * @param oppositeComboBox The opposite comboBox to the one clicked.
     */
    private void check(ComboBox oppositeComboBox) {
        // Check if the combobox has been set up.
        if (oppositeComboBox.getSelectionModel().getSelectedItem() != null) {
            // Check if price range has been chosen correctly.
            if (properties.getSelectedMinValue() > properties.getSelectedMaxValue()) {
                Alert alert = new Alert(AlertType.ERROR);
                alert.setTitle("Incorrect price range");
                alert.setHeaderText(null);
                alert.setContentText("Ops, your maximum price is less than your minimum price! \n" +
                        "Please, choose a valid number.");
                alert.getDialogPane().setMinHeight(Region.USE_PREF_SIZE);
                alert.showAndWait();
            }
            // Display a message, saying that we are good to go.
            else {
                if(previous.isDisable()) {
                    enableButtons();
                }
                controllerWelcome.setPriceDisplay(properties.getSelectedMinValue(), properties.getSelectedMaxValue());
                setSelectedProperties();
            }
        }
        controllerMap.generateMap(properties.getListings(), properties.getSelectedMinValue(), properties.getSelectedMaxValue());
    }

    /**
     * Enable buttons to move between panes.
     * Also, display a dialog to make the user aware.
     */
    public void enableButtons() {
        next.setDisable(false);
        previous.setDisable(false);
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle("You are ready to go!");
        alert.setHeaderText(null);
        alert.setContentText("Press next to see the map of the available properties.");
        alert.getDialogPane().setMinHeight(Region.USE_PREF_SIZE);
        alert.showAndWait();
    }

    /**
     * Select the properties corresponding to the price range set.
     */
    private void setSelectedProperties() {
        selectedListings.clear();
        for (AirbnbListing property : properties.getListings()) {
            if (property.getPrice() >= properties.getSelectedMinValue() &&
                    property.getPrice() <= properties.getSelectedMaxValue()) {
                selectedListings.add(property);
            }
        }
    }
}

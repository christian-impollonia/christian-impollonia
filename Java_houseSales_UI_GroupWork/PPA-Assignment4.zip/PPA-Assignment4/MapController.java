import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;

import java.util.*;

/**
 * A simple controller for the map pane.
 * Generate the map with the different boroughs.
 *
 * @author Alfredo Musumeci
 * @version 2020/03/14
 */
public class MapController {
    // Pane containing the map.
    @FXML
    private AnchorPane pane;
    // A window for any borough to be created once a button is pressed.
    private BoroughWindow boroughWindow;
    // Array-prototype of the map.
    private String[][] map;
    // Collection of neighbourhood, codeName and neighbourhood.
    private HashMap<String, String> neighbourhoods;
    // Collection of buttons and of number of properties they store.
    private HashMap<Button, Integer> buttons;

    /**
     * Constructor for class MapController.
     * Set up the window to be used for the boroughs,
     * links the neighbourhood and design the map.
     */
    public MapController() {
        boroughWindow = new BoroughWindow();
        neighbourhoods = new HashMap<>();
        buttons = new HashMap<>();

        linkNeighbourhood();
        designMap();
    }

    /**
     * Link each code name to its extended neighbourhood name.
     */
    private void linkNeighbourhood() {
        neighbourhoods.put("ENFI", "Enfield");
        neighbourhoods.put("BARN", "Barnet");
        neighbourhoods.put("HRGY", "Haringey");
        neighbourhoods.put("WALT", "WalthamForest");
        neighbourhoods.put("HRRW", "Harrow");
        neighbourhoods.put("BREN", "Brent");
        neighbourhoods.put("CAMD", "Camden");
        neighbourhoods.put("ISLI", "Islington");
        neighbourhoods.put("HACK", "Hackney");
        neighbourhoods.put("REDB", "Redbridge");
        neighbourhoods.put("HAVE", "Havering");
        neighbourhoods.put("HILL", "Hillingdon");
        neighbourhoods.put("EALI", "Ealing");
        neighbourhoods.put("KENS", "KensingtonandChelsea");
        neighbourhoods.put("WSTM", "Westminster");
        neighbourhoods.put("TOWH", "TowerHamlets");
        neighbourhoods.put("NEWH", "Newham");
        neighbourhoods.put("BARK", "BarkingandDagenham");
        neighbourhoods.put("HOUN", "Hounslow");
        neighbourhoods.put("HAMM", "HammersmithandFulham");
        neighbourhoods.put("WAND", "Wandsworth");
        neighbourhoods.put("CITY", "CityofLondon");
        neighbourhoods.put("GWCH", "Greenwich");
        neighbourhoods.put("BEXL", "Bexley");
        neighbourhoods.put("RICH", "RichmonduponThames");
        neighbourhoods.put("MERT", "Merton");
        neighbourhoods.put("LAMB", "Lambeth");
        neighbourhoods.put("STHW", "Southwark");
        neighbourhoods.put("LEWS", "Lewisham");
        neighbourhoods.put("KING", "KingstonuponThames");
        neighbourhoods.put("SUTT", "Sutton");
        neighbourhoods.put("CROY", "Croydon");
        neighbourhoods.put("BROM", "Bromley");
    }

    /**
     * Generate the map, that is, create the buttons and put
     * them at a specific distance, populate them with properties
     * and update colors.
     * @param properties The listing of properties.
     * @param minPrice Minimum price to search from.
     * @param maxPrice Maximum price to search to.
     */
    public void generateMap(List<AirbnbListing> properties, int minPrice, int maxPrice) {
        // Horizontal displacement between buttons.
        double x = 0;
        // Vertical displacement between buttons.
        double y = 0;
        // First row is considered even.
        // 0 even, 1 odd.
        int indRow = 0;

        // Prevent duplication of buttons.
        pane.getChildren().clear();
        // Set the maximum number of properties to zero.
        buttons.clear();

        for(String[] row : map) {
            for(String each : row) {
                if(!each.equals("")) {
                    Button button = new Button();
                    button.setStyle("");
                    button.setLayoutX(x);
                    button.setLayoutY(y);
                    button.setText(each);
                    pane.getChildren().add(button);

                    List<AirbnbListing> propertiesPerBorough = new LinkedList<>(properties);
                    propertiesPerBorough.removeIf(p -> !p.getNeighbourhood().replaceAll("\\s+", "").equals(neighbourhoods.get(each)));
                    propertiesPerBorough.removeIf(p -> !(p.getPrice() >= minPrice && p.getPrice() <= maxPrice));
                    buttons.put(button, propertiesPerBorough.size());

                    button.setOnAction(event -> {
                        // Empty the list to prepare it for a new borough.
                        boroughWindow.getProperties().clear();
                        // Populate the list with properties.
                        for(AirbnbListing property : propertiesPerBorough){
                                    boroughWindow.getProperties().add(property);
                        }
                        // No properties for the given price range have been found.
                        if(boroughWindow.getProperties().isEmpty()) {
                            Alert alert = new Alert(Alert.AlertType.ERROR);
                            alert.setTitle("No properties found");
                            alert.setHeaderText(null);
                            alert.setContentText("Ops, it seems that there are no properties in this " +
                                    "borough for your price range. \n" + "Try using a different price range.");
                            alert.getDialogPane().setMinHeight(Region.USE_PREF_SIZE);
                            alert.showAndWait();
                        }
                        else {
                            // Load the borough window, with the properties.
                            boroughWindow.setUpWindow(boroughWindow.getProperties());
                            boroughWindow.showWindow(neighbourhoods.get("" + button.getText()), boroughWindow.getBoroughPane());
                        }
                    });
                }
                x += 90;
            }
            indRow++;
            // Adjust the following rows respectively to the right or to the left.
            // On even row (remainder 0), x is increased by 0.
            // On odd row (remainder 1), x is set to its half.
            x = (indRow % 2 == 1) ? 45 : 0;
            y += 70;
        }
        updateColor();
    }

    /**
     * Update the color of the buttons according
     * to the maximum number of properties.
     */
    public void updateColor() {
        int maxProperties = Collections.max(buttons.values());
        // If there is at least one property for the price range selected, apply custom colors.
        if (maxProperties > 0) {
            int C;
            for (Button each : buttons.keySet()) {
                C = (buttons.get(each) * 255 / maxProperties - 255) * (-1);
                String color = Integer.toHexString(C);
                if (color.length() == 1) {
                    color = "0" + color;
                }

                each.setBackground(new Background(new BackgroundFill(Color.web("#" + color + "ff" + color),
                        CornerRadii.EMPTY, Insets.EMPTY)));
            }
        }
        // Else, paint them all white.
        else {
            for (Button each : buttons.keySet()) {
                each.setBackground(new Background(new BackgroundFill(Color.WHITE, CornerRadii.EMPTY, Insets.EMPTY)));
            }
        }
    }

    /**
     * Create the array that will be used to build the map.
     */
    private void designMap() {
        map = new String[][]{
                {"","","","","ENFI","","",""},
                {"","","BARN","HRGY","WALT","","",""},
                {"","HRRW","BREN","CAMD","ISLI","HACK","REDB","HAVE"},
                {"HILL","EALI","KENS","WSTM","TOWH","NEWH","BARK",""},
                {"","HOUN","HAMM","WAND","CITY","GWCH","BEXL",""},
                {"","RICH","MERT","LAMB","STHW","LEWS","",""},
                {"","","KING","SUTT","CROY","BROM","",""},
        };
    }
}
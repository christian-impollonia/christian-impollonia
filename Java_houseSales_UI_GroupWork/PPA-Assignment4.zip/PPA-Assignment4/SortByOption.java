import javafx.scene.control.TableColumn;

/**
 * A class to create the sort-by options.
 * A new option must have its respective column
 * in the TableView of BoroughController.
 *
 * @author Alfredo Musumeci
 * @version 2020/03/24
 */
public class SortByOption {
    // The sorting-by option, i.e. price.
    private String option;
    // The columnName of the desired sorting by option.
    private TableColumn<AirbnbListing, String> columnName;

    /**
     * Constructor for class SortByOption.
     * Create a new SortByOption.
     * @param option The name of the desired sort-by option, i.e. price.
     * @param columnName The name of the respective column in the TableView.
     */
    public SortByOption(String option, TableColumn<AirbnbListing, String> columnName) {
        this.option = option;
        this.columnName = columnName;
    }

    /**
     * Return the name of the option.
     * @return The name of the option.
     */
    public String getOption() {
        return option;
    }

    /**
     * Override the toString method to get the name
     * of the option when a new object is created.
     * @return The name of the option.
     */
    @Override
    public String toString() {
        return getOption();
    }

    /**
     * Return the columnName of the option.
     * @return The columnName of the option.
     */
    public TableColumn<AirbnbListing, String> getColumnName() {
        return columnName;
    }
}

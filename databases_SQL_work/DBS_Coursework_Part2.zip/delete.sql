-- Part 2.5 delete.sql
--
-- Submitted by: <Christian Impollonia>, <1902896>
-- 

-- DO NOT use these SQL commands in your submission(they will cause an 
--  error on the NMS database server):
-- CREATE SCHEMA 
-- USE 

-- Because referential integrity constraint violation handling was set as cascade participant on deletion of contender, all participants
-- associated with a contender are deleted from the database when that contender is deleted. So this code will delete the contender that
-- is paid the least as well as any participant forming that contender

delete from contender where (stageName = (select stageName from (select topName as stageName, min(paySum) as totalDailyPay from (select c.stageName as topName, sum(p.dailySalary) as paySum from contender c, participant p where
 p.contender = c.idContender group by c.idContender order by paySum asc) as maxSum) as minName));


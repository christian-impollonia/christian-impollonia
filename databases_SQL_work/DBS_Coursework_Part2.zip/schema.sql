-- Part 2.1 schema.sql
--
-- Submitted by: <Christian Impollonia>, <1902896>
-- 

-- DO NOT use these SQL commands in your submission(they will cause an 
--  error on the NMS database server):
-- CREATE SCHEMA 
-- USE

-- For this schema, for the creation of primary keys, not null and unique statements were avoided because redundant.
-- Primary keys are both of these things by default.

 -- Creation of table TVShow
    -- The "date" attribute specified in the relational schema was changed to 
    -- ""showDate" because date is a reserved word for sql.
    -- The "location" attribute specified in the relational schema was changed to 
    -- ""showLocation" because location is a reserved word for sql.
    -- ShowLocation is set as 'TV Studio' for default because of the initial requirements
    create table tv_show(
        idShow varchar(10),
        showDate date not null,
        startTime time not null,
        endTime time not null,
        showLocation varchar(25) default 'TV Studio',
        primary key(idShow)
    );

    -- Creation of table Coach
    -- For gender, the type char was used, with 1 character, that can be m, f or u(unspecified)
    -- Normally, a check would have been implemented (or a custom domain) to make sure than gender can only be 'm', 'f', or 'u',
    -- but the version of mysql on the nms database does not support the function, so it was omitted. But that would have been the approach used. 
    -- An assumption was made regarding the salary of coaches, that is that it can never be null.
    -- Not excluding the idea that coaches can be on the program for free, the value of the salary
    -- attribute will be 0 in that case. That will also make finding unpaid people easier.
    -- There is no reason to have the value be null.
    create table coach(
        idCoach varchar(10),
        name varchar(15) not null,
        surname varchar(15) not null,
        DoB date not null,
        phone varchar(15) unique,
        dailySalary float not null,
        gender char(1) not null,
        primary key(idCoach)
    );

    -- Creation of table Contender
-- For the "type" attribute specified in the relational schema, there were a few changes.
-- Because type is a reserved word in sql code, and because the plan is to have it only store 2 possible values,
-- I chose to make it a boolean, and call it isIndividual, which will be true if the contestant is an indivual, and 
-- false if it is a group.
-- For the foreign keys, it was thought that the best approach is to restrict most kinds of alterations of parent tables
-- (when not specifically asked) in case there are keys in common. Mysql does this by default with the no action keyword.
-- The assignment specification asked that if the coach leaves the show, they should be removed from the database and 
-- the contender should be given a replacement coach. This approach can be done by having one of the coaches set as the general replacement coach,
-- and when a deletion happens, the contender is assigned that coach. That can be done with the keywords ('on delete set default'), by having
-- the replacement coach as a default, as shown below. But the nms mysql database doesn't support the 'on delete set default' command, so this can not
-- be correctly implemented. For this reason there will be a set null on delete instead of a set default, but the conceptual idea
-- of how the schema should actually handle this constraint violation is reported in these comments.
    create table contender(
    idContender varchar(10),
    stageName varchar(20) unique not null,
    isIndividual boolean not null,
    coach varchar(10) default '01REPCOACH',
    primary key(idContender),
    foreign key(coach) references coach(idCoach)
    on delete set null
    on update no ACTION
    );

-- Creation of Table Participant
-- For gender, the type char was used, with 1 character, that can be m, f, or u(unkwown)
-- Normally, a check would have been implemented (or a custom domain) to make sure than gender can only be 'm', 'f', or 'u',
-- but the version of mysql on the nms database does not support the function, so it was omitted. But that would have been the approach used. 
-- An assumption was made regarding the salary of participants, that is that it can never be null.
-- Not excluding the idea that participants can be on the program for free, the value of the salary
-- attribute will be 0 in that case. That will also make finding unpaid people easier.
-- There is no reason to have the value be null.
-- For the foreign keys, because they are very closely related data, the chosen approach was to cascade.
-- So when the contenderID is deleted, the same happens to the one in the participant table.
-- There would be no reason to keep data from one table but not the other.
-- Action on update is same as the standard for this schema
create table participant(
    idParticipant varchar(10),
    name varchar(15) not null,
    surname varchar(15) not null,
    DoB date not null,
    phone varchar(15) unique,
    dailySalary float not null,
    gender char(1) not null,
    contender varchar(10),
    primary key(idParticipant),
    foreign key(contender) references contender(idContender)
    on delete CASCADE
    on update no action
);

    -- Creation of table ContenderInShow
    -- Because "show" is a reserved word in mysql, it was changed to "TVShow"
    -- relational schema
    -- For the foreign keys, it was thought that a contender or show shouldn't be able to be deleted because it would
    -- sabotage the data that correlates the two. But because a show can go on for long, and a show ID
    -- can be formed, for example of airing date and channel, that are variable, 
    -- it should be able to be updated, and the correlation between contender and show with it.
        create table contender_in_show(
        contender varchar(10),
        TVShow varchar(10),
        primary key(contender, TVShow),
        foreign key(contender) references contender(idContender)
        on delete no action
        on update no action,
        foreign key(TVShow) references tv_show(idShow)
        on delete no action
        on update CASCADE
    );

    -- Creation of table CoachInShow
    -- Because "show", from the relational schema, is a reserved word in mysql, it was changed to "TVShow"
    -- For the foreign keys, it was thought that a coach or show shouldn't be able to be deleted because it would
    -- sabotage the data that correlates the two. But given the tasksheet requirements, when a coach leaves all the relative
    -- data needs to be deleted from the database. So a cascade approach was chosen exclusively for the coach table. 
    -- Because a show can go on for long, and a show ID can be formed, for example of airing date and channel, that are variable, 
    -- it should be able to be updated, and the correlation between contender and show with it.
         create table coach_in_show(
             coach varchar(10),
             TVShow varchar(10),
             primary key(coach, TVShow),
             foreign key(coach) references coach(idCoach)
             on delete CASCADE
             on update no action,
             foreign key(TVShow) references tv_show(idShow)
             on delete no action
             on update cascade
         );








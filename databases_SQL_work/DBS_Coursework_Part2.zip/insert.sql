-- Part 2.2 insert.sql
--
-- Submitted by: <Christian Impollonia>, <1902896>
-- 

-- DO NOT use these SQL commands in your submission(they will cause an 
--  error on the NMS database server):
-- CREATE SCHEMA 
-- USE 

--Insertion of 5 Coaches

-- Replacement coach in case a coach leaves
insert into coach(
    dailySalary, gender, name, surname, DoB, idCoach, phone
)
values(
    100, 'M', 'Mika', 'Mika', '1983-08-18', '01REPCOACH', '+3739374849278' 
);

insert into coach(
    dailySalary, gender, name, surname, DoB, idCoach, phone
)
values(
    500, 'M', 'Simon', 'Cowell', '1959-10-07', '001SC', '+447754683546' 
);

insert into coach(
    dailySalary, gender, name, surname, DoB, idCoach, phone
)
values(
   350, 'M', 'Piers', 'Morgan', '1965-03-30', '001PM', '+447640268392' 
);

insert into coach(
    dailySalary, gender, name, surname, DoB, idCoach, phone
)
values(
    450, 'F', 'Cheryl', 'Cole', '1983-06-30', '001CC', '+447729384521' 
);

--Insertion of shows
-- Following the assignment requirements, all shows happen during march and april on weekends.
-- Most shows happen at the default location the TV Studio, but some take place in other locations.
-- They last 2 hours and start at 20 on saturday and 21 on sunday, but that can also change sometimes.

insert into tv_show(
    idShow, showDate, startTime, endTime
)
values(
    '0001MAR', '2019-03-02', '20:00', '22:00'
);

insert into tv_show(
    idShow, showDate, startTime, endTime
)
values(
    '0002MAR', '2019-03-03', '21:00', '23:00'
);

insert into tv_show(
    idShow, showDate, startTime, endTime
)
values(
    '0003MAR', '2019-03-09', '19:00', '21:00'
);

insert into tv_show(
    idShow, showDate, startTime, endTime
)
values(
    '0004MAR', '2019-03-10', '21:00', '23:00'
);

insert into tv_show(
    idShow, showDate, startTime, endTime
)
values(
    '0005MAR', '2019-03-16', '21:00', '23:00'
);

insert into tv_show(
    idShow, showDate, showLocation, startTime, endTime
)
values(
    '0006MAR', '2019-04-17', 'Royal Opera House', '21:00', '23:00'
);

insert into tv_show(
    idShow, showDate, startTime, endTime
)
values(
    '0007MAR', '2019-03-23', '19:30', '21:30'
);

insert into tv_show(
    idShow, showDate, startTime, endTime
)
values(
    '0008MAR', '2019-03-24', '20:00', '22:00'
);

insert into tv_show(
    idShow, showDate, startTime, endTime
)
values(
    '0009MAR', '2019-03-30', '20:00', '22:00'
);

insert into tv_show(
    idShow, showDate, showLocation, startTime, endTime
)
values(
    '0010MAR', '2019-03-31', 'San Siro', '21:00', '23:00'
);

insert into tv_show(
    idShow, showDate, startTime, endTime
)
values(
    '0001APR', '2019-04-06', '17:00', '19:00'
);

insert into tv_show(
    idShow, showDate, startTime, endTime
)
values(
    '0002APR', '2019-04-07', '19:30', '21:30'
);

insert into tv_show(
    idShow, showDate, showLocation, startTime, endTime
)
values(
    '0003APR', '2019-04-13', 'Wembley', '21:00', '23:00'
);

insert into tv_show(
    idShow, showDate, startTime, endTime
)
values(
    '0004APR', '2019-04-14', '20:00', '22:00'
);

insert into tv_show(
    idShow, showDate, startTime, endTime
)
values(
    '0005APR', '2019-04-20', '20:00', '22:00'
);

insert into tv_show(
    idShow, showDate, startTime, endTime
)
values(
    '0006APR', '2019-04-21', '21:00', '23:00'
);

insert into tv_show(
    idShow, showDate, showLocation, startTime, endTime
)
values(
    '0007APR', '2019-04-27', 'Elstree Studios', '20:30', '22:30'
);

insert into tv_show(
    idShow, showDate, startTime, endTime
)
values(
    '0008APR', '2019-04-28', '20:30', '22:30'
);



--Insertion of 5 contenders
insert into contender(
    idContender, stageName, isIndividual, coach
)
values(
    'CR001', 'The Chris', true, '001SC'
);

insert into contender(
    idContender, stageName, isIndividual, coach
)
values(
    'TD001', 'Dods Family', false, '001PM'
);

insert into contender(
    idContender, stageName, isIndividual, coach
)
values(
    'YD001', 'Your Dad', true, '001CC'
);

insert into contender(
    idContender, stageName, isIndividual, coach
)
values(
    'SM001', 'Samp Man', true, '001PM'
);

insert into contender(
    idContender, stageName, isIndividual, coach
)
values(
    'DN001', 'DENICOLAZ', false, '001CC'
);
-- This contender was added, as asked in the tasksheet, to act as a test for the sixth select statement. It is in fact inserted as a group,
-- but will only have one participant related to it. So because if this, it will make the query output false.
insert into contender(
    idContender, stageName, isIndividual, coach
)
values(
    'TG001', 'Test Group for check', false, '001SC'
);


--Insertion of 10 participants
insert into participant(
    idParticipant, name, surname, DoB, phone, dailySalary, gender, contender
)
values(
    '001MEL', 'Melissa', 'Cornet-Clark', '2004-05-18', '+447982672185', 50, 'F', 'TD001'
);

insert into participant(
    idParticipant, name, surname, DoB, phone, dailySalary, gender, contender
)
values(
    '001CHR', 'Christian', 'Impollonia', '2000-10-02', '+447765063925', 80, 'M', 'CR001'
);

insert into participant(
    idParticipant, name, surname, DoB, phone, dailySalary, gender, contender
)
values(
    '001DAV', 'David', 'Clark', '1968-02-19', '+447710541556', 60, 'M', 'YD001'
);

insert into participant(
    idParticipant, name, surname, DoB, phone, dailySalary, gender, contender
)
values(
    '001OLL', 'Ollie', 'Dods', '2004-06-06', '+447733684522', 50, 'M', 'TD001'
);

insert into participant(
    idParticipant, name, surname, DoB, phone, dailySalary, gender, contender
)
values(
    '001ELL', 'Ella', 'Lawyer', '2004-11-02', '+447836493684', 50, 'F', 'TD001'
);

insert into participant(
    idParticipant, name, surname, DoB, phone, dailySalary, gender, contender
)
values(
    '002DAV', 'David', 'Impollonia', '2001-12-29', '+393272932128', 70, 'M', 'SM001'
);

insert into participant(
    idParticipant, name, surname, DoB, phone, dailySalary, gender, contender
)
values(
    '001AVA', 'Ava', 'Fakeblonde', '2004-07-09', '+447354925492', 50, 'F', 'TD001'
);

insert into participant(
    idParticipant, name, surname, DoB, phone, dailySalary, gender, contender
)
values(
    '001LEO', 'Leonardo', 'De Nicola', '2002-02-01', '+392793037939', 60, 'M', 'DN001'
);

insert into participant(
    idParticipant, name, surname, DoB, phone, dailySalary, gender, contender
)
values(
    '001MAR', 'Marco', 'De Nicola', '1957-05-24', '+396839363834', 65, 'M', 'DN001'
);

insert into participant(
    idParticipant, name, surname, DoB, phone, dailySalary, gender, contender
)
values(
    '001FRA', 'Francesca', 'Cari', '1966-03-17', '+393265438771', 60, 'F', 'DN001'
);
-- This participant was added, as asked in the tasksheet, to act as a test for the sixth select statement. It is in fact the only
-- participant inserted in a group, so because if this, it will make the query output false.
insert into participant(
    idParticipant, name, surname, DoB, phone, dailySalary, gender, contender
)
values(
    '001TEST', 'Test', 'Select', '2020-03-17', '+9999999999', 50, 'S', 'TG001'
);

--Insertion of 3 attendances per show of contenders
insert into contender_in_show(
    TVShow, contender
)
values (
    '0001MAR', 'CR001'
);

insert into contender_in_show(
    TVShow, contender
)
values (
    '0001MAR', 'TD001'
);

insert into contender_in_show(
    TVShow, contender
)
values (
    '0001MAR', 'YD001'
);

insert into contender_in_show(
    TVShow, contender
)
values (
    '0002MAR', 'YD001'
);

insert into contender_in_show(
    TVShow, contender
)
values (
    '0002MAR', 'SM001'
);

insert into contender_in_show(
    TVShow, contender
)
values (
    '0002MAR', 'DN001'
);

insert into contender_in_show(
    TVShow, contender
)
values (
    '0003MAR', 'SM001'
);

insert into contender_in_show(
    TVShow, contender
)
values (
    '0003MAR', 'TD001'
);

insert into contender_in_show(
    TVShow, contender
)
values (
    '0003MAR', 'CR001'
);

insert into contender_in_show(
    TVShow, contender
)
values (
    '0004MAR', 'DN001'
);

insert into contender_in_show(
    TVShow, contender
)
values (
    '0004MAR', 'CR001'
);

insert into contender_in_show(
    TVShow, contender
)
values (
    '0004MAR', 'YD001'
);

insert into contender_in_show(
    TVShow, contender
)
values (
    '0005MAR', 'DN001'
);

insert into contender_in_show(
    TVShow, contender
)
values (
    '0005MAR', 'TD001'
);

insert into contender_in_show(
    TVShow, contender
)
values (
    '0005MAR', 'SM001'
);

insert into contender_in_show(
    TVShow, contender
)
values (
    '0006MAR', 'CR001'
);

insert into contender_in_show(
    TVShow, contender
)
values (
    '0006MAR', 'TD001'
);

insert into contender_in_show(
    TVShow, contender
)
values (
    '0006MAR', 'YD001'
);

insert into contender_in_show(
    TVShow, contender
)
values (
    '0007MAR', 'YD001'
);

insert into contender_in_show(
    TVShow, contender
)
values (
    '0007MAR', 'SM001'
);

insert into contender_in_show(
    TVShow, contender
)
values (
    '0007MAR', 'DN001'
);

insert into contender_in_show(
    TVShow, contender
)
values (
    '0008MAR', 'SM001'
);

insert into contender_in_show(
    TVShow, contender
)
values (
    '0008MAR', 'TD001'
);

insert into contender_in_show(
    TVShow, contender
)
values (
    '0008MAR', 'CR001'
);

insert into contender_in_show(
    TVShow, contender
)
values (
    '0009MAR', 'DN001'
);

insert into contender_in_show(
    TVShow, contender
)
values (
    '0009MAR', 'CR001'
);

insert into contender_in_show(
    TVShow, contender
)
values (
    '0009MAR', 'YD001'
);

insert into contender_in_show(
    TVShow, contender
)
values (
    '0010MAR', 'DN001'
);

insert into contender_in_show(
    TVShow, contender
)
values (
    '0010MAR', 'TD001'
);

insert into contender_in_show(
    TVShow, contender
)
values (
    '0010MAR', 'SM001'
);

insert into contender_in_show(
    TVShow, contender
)
values (
    '0001APR', 'CR001'
);

insert into contender_in_show(
    TVShow, contender
)
values (
    '0001APR', 'TD001'
);

insert into contender_in_show(
    TVShow, contender
)
values (
    '0001APR', 'YD001'
);

insert into contender_in_show(
    TVShow, contender
)
values (
    '0002APR', 'YD001'
);

insert into contender_in_show(
    TVShow, contender
)
values (
    '0002APR', 'SM001'
);

insert into contender_in_show(
    TVShow, contender
)
values (
    '0002APR', 'DN001'
);

insert into contender_in_show(
    TVShow, contender
)
values (
    '0003APR', 'SM001'
);

insert into contender_in_show(
    TVShow, contender
)
values (
    '0003APR', 'TD001'
);

insert into contender_in_show(
    TVShow, contender
)
values (
    '0003APR', 'CR001'
);

insert into contender_in_show(
    TVShow, contender
)
values (
    '0004APR', 'DN001'
);

insert into contender_in_show(
    TVShow, contender
)
values (
    '0004APR', 'CR001'
);

insert into contender_in_show(
    TVShow, contender
)
values (
    '0004APR', 'YD001'
);

insert into contender_in_show(
    TVShow, contender
)
values (
    '0005APR', 'DN001'
);

insert into contender_in_show(
    TVShow, contender
)
values (
    '0005APR', 'TD001'
);

insert into contender_in_show(
    TVShow, contender
)
values (
    '0005APR', 'SM001'
);

insert into contender_in_show(
    TVShow, contender
)
values (
    '0006APR', 'CR001'
);

insert into contender_in_show(
    TVShow, contender
)
values (
    '0006APR', 'TD001'
);

insert into contender_in_show(
    TVShow, contender
)
values (
    '0006APR', 'YD001'
);

insert into contender_in_show(
    TVShow, contender
)
values (
    '0007APR', 'YD001'
);

insert into contender_in_show(
    TVShow, contender
)
values (
    '0007APR', 'SM001'
);

insert into contender_in_show(
    TVShow, contender
)
values (
    '0007APR', 'DN001'
);

insert into contender_in_show(
    TVShow, contender
)
values (
    '0008APR', 'SM001'
);

insert into contender_in_show(
    TVShow, contender
)
values (
    '0008APR', 'TD001'
);

insert into contender_in_show(
    TVShow, contender
)
values (
    '0008APR', 'CR001'
);



--Insertion of 2 attendances of coaches per show
insert into coach_in_show(
    TVShow, coach
)
values (
   '0001MAR', '001SC'
);

insert into coach_in_show(
    TVShow, coach
)
values (
   '0001MAR', '001CC'
);

insert into coach_in_show(
    TVShow, coach
)
values (
   '0002MAR', '001PM'
);

insert into coach_in_show(
    TVShow, coach
)
values (
   '0002MAR', '001CC'
);

insert into coach_in_show(
    TVShow, coach
)
values (
   '0003MAR', '001SC'
);

insert into coach_in_show(
    TVShow, coach
)
values (
   '0003MAR', '001PM'
);

insert into coach_in_show(
    TVShow, coach
)
values (
   '0004MAR', '001CC'
);

insert into coach_in_show(
    TVShow, coach
)
values (
   '0004MAR', '001PM'
);

insert into coach_in_show(
    TVShow, coach
)
values (
   '0005MAR', '001SC'
);

insert into coach_in_show(
    TVShow, coach
)
values (
   '0005MAR', '001CC'
);

insert into coach_in_show(
    TVShow, coach
)
values (
   '0006MAR', '001SC'
);

insert into coach_in_show(
    TVShow, coach
)
values (
   '0006MAR', '001CC'
);

insert into coach_in_show(
    TVShow, coach
)
values (
   '0007MAR', '001PM'
);

insert into coach_in_show(
    TVShow, coach
)
values (
   '0007MAR', '001CC'
);

insert into coach_in_show(
    TVShow, coach
)
values (
   '0008MAR', '001SC'
);

insert into coach_in_show(
    TVShow, coach
)
values (
   '0008MAR', '001PM'
);

insert into coach_in_show(
    TVShow, coach
)
values (
   '0009MAR', '001CC'
);

insert into coach_in_show(
    TVShow, coach
)
values (
   '0009MAR', '001PM'
);

insert into coach_in_show(
    TVShow, coach
)
values (
   '0010MAR', '001SC'
);

insert into coach_in_show(
    TVShow, coach
)
values (
   '0010MAR', '001CC'
);

insert into coach_in_show(
    TVShow, coach
)
values (
   '0001APR', '001SC'
);

insert into coach_in_show(
    TVShow, coach
)
values (
   '0001APR', '001CC'
);

insert into coach_in_show(
    TVShow, coach
)
values (
   '0002APR', '001PM'
);

insert into coach_in_show(
    TVShow, coach
)
values (
   '0002APR', '001CC'
);

insert into coach_in_show(
    TVShow, coach
)
values (
   '0003APR', '001SC'
);

insert into coach_in_show(
    TVShow, coach
)
values (
   '0003APR', '001PM'
);

insert into coach_in_show(
    TVShow, coach
)
values (
   '0004APR', '001CC'
);

insert into coach_in_show(
    TVShow, coach
)
values (
   '0004APR', '001PM'
);

insert into coach_in_show(
    TVShow, coach
)
values (
   '0005APR', '001SC'
);

insert into coach_in_show(
    TVShow, coach
)
values (
   '0005APR', '001CC'
);

insert into coach_in_show(
    TVShow, coach
)
values (
   '0006APR', '001SC'
);

insert into coach_in_show(
    TVShow, coach
)
values (
   '0006APR', '001CC'
);

insert into coach_in_show(
    TVShow, coach
)
values (
   '0007APR', '001PM'
);

insert into coach_in_show(
    TVShow, coach
)
values (
   '0007APR', '001CC'
);

insert into coach_in_show(
    TVShow, coach
)
values (
   '0008APR', '001SC'
);

insert into coach_in_show(
    TVShow, coach
)
values (
   '0008APR', '001PM'
);














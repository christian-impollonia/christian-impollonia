-- Part 2.4 update.sql
--
-- Submitted by: <Christian Impollonia>, <1902896>
-- 

-- DO NOT use these SQL commands in your submission(they will cause an 
--  error on the NMS database server):
-- CREATE SCHEMA 
-- USE 

-- Make the daily salary hourly
alter table coach change dailySalary hourlySalary float;
alter table participant change dailySalary hourlySalary float;
update coach set hourlySalary = hourlySalary/4;
update participant set hourlySalary = hourlySalary/4;

-- Add arrival time
alter table contender_in_show add arrivalTime time;
alter table coach_in_show add arrivalTime time;

-- Add leaving time
alter table contender_in_show add leavingTime time;
alter table coach_in_show add leavingTime time;

-- Update tables with new arrival and leaving times
update coach_in_show cs join tv_show t on cs.TVShow = t.idShow set cs.arrivalTime = (addtime(t.startTime, '-1:00:00'));
update coach_in_show cs join tv_show t on cs.TVShow = t.idShow set cs.leavingTime = (addtime(t.endTime, '1:00:00'));
update contender_in_show cs join tv_show t on cs.TVShow = t.idShow set cs.arrivalTime = (addtime(t.startTime, '-1:00:00'));
update contender_in_show cs join tv_show t on cs.TVShow = t.idShow set cs.leavingTime = (addtime(t.endTime, '1:00:00'));







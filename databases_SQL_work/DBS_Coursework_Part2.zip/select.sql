-- Part 2.3 select.sql
--
-- Submitted by: <Christian Impollonia>, <1902896>
-- 

-- DO NOT use these SQL commands in your submission(they will cause an 
--  error on the NMS database server):
-- CREATE SCHEMA 
-- USE 


-- 1. Average Female Salary
select avg(dailySalary) as averageFemaleDailySalary from participant where gender='F';


-- 2. Coaching Report. 
select c.name, c.surname, count(d.coach) as numberOfContenders from (contender d right outer join coach as c on d.coach = c.idCoach) group by c.idCoach;


-- 3. Coach Monthly Attendance Report
-- The tasksheet required to report attendance for each month, but was quite vague in specifying if there should be results
-- for months other than march and april, that are the only months the show is actually taking place. Because of what the actual request
-- was, I assumed it was meant only for march and april, because if that wasn't the case, the query would result with 10 empty rows and it
-- would also need a huge amount of code to specify every different month check.
-- Also, because not specified otherwise, the report shows only coaches that have actually attended the show in march and april (so not the replacement coach if he has not replaced anyone)
select coachName, coachSurname, marchCount, aprilCount from (select c.idCoach as coachID, c.name as coachName, c.surname as coachSurname, count(cs.TVShow) as marchCount from tv_show t, 
coach c, coach_in_show cs where t.idShow = cs.TVShow and c.idCoach = cs.coach
and month(t.showDate) = '03' group by cs.coach) as firstSelection join (select c.idCoach as coachID2, count(cs.TVShow) as aprilCount from tv_show t, coach_in_show cs, coach c where t.idShow = cs.TVShow
and c.idCoach = cs.coach and month(t.showDate) = '04' group by cs.coach) as secondSelection on coachID = coachID2;


-- 4. Most Expensive Contender
select topName as stageName, max(paySum) as totalDailyPay from (select c.stageName as topName, sum(p.dailySalary) as paySum from contender c, participant p where
 p.contender = c.idContender group by c.idContender order by paySum desc) as maxSum;


-- 5. March Payment Report
-- List of shows attended and pay due for march for each person involved
    select concat(coachName, ' ', coachSurname, ' ', showsAttendedInMarch, ' ' ,coachDailySalary, ' ', marchSalary) as MarchReport from (
    select c.name as coachName, c.surname as coachSurname, count(cs.TVShow) as showsAttendedInMarch, c.dailySalary as coachDailySalary, 
    count(cs.TVShow)*c.dailySalary as marchSalary from coach_in_show cs, tv_show t, 
    coach c where t.idShow = cs.TVShow and c.idCoach = cs.coach and (month(t.showDate) = '03') group by cs.coach) as coachReport
     UNION
     select concat(participantName, ' ' ,participantSurname, ' ' ,showsAttendedInMarch, ' ' ,participantDailySalary, ' ' ,marchSalary) from (
     select p.name as participantName, p.surname as participantSurname, count(ds.TVShow) as showsAttendedInMarch, p.dailySalary as 
     participantDailySalary, count(ds.TVShow)*p.dailySalary as marchSalary from contender_in_show ds, tv_show t, 
     participant p, contender d where t.idShow = ds.TVShow and p.contender = d.idContender and d.idContender = ds.contender and 
     (month(t.showDate) = '03') group by p.idParticipant) as participantReport
     UNION
  select concat('Total amount due: ' ,cast((coachSum + participantSum) as char(10))) as totalAmountDueInMarch from(
    select sum(coachSelect.payCount) as coachSum from (select count(cs.TVShow)*c.dailySalary as payCount from coach_in_show cs, tv_show t, 
    coach c where t.idShow = cs.TVShow and c.idCoach = cs.coach and (month(t.showDate) = '03') group by cs.coach) as coachSelect) as coachTotalSelect,
    (select sum(participantSelect.payCount) as participantSum from (select count(ds.TVShow)*p.dailySalary as payCount from contender_in_show ds, tv_show t, 
     participant p, contender d where t.idShow = ds.TVShow and p.contender = d.idContender and d.idContender = ds.contender and 
     (month(t.showDate) = '03') group by p.idParticipant) as participantSelect) as participantTotalSelect;


-- 6. Well Formed Groups!
-- The opposite constraint (an individual contender shouldn't have more than one participant) is a valid one to add but wasn't considered
-- because not specifically asked in the assignment sheet. Therefore only the case where a group is formed by only one participant is checked.
select case when exists (
    select* from(select count(p.contender) as formedBy, p.contender from(select isIndividual as totalGroups, idContender as contID from contender where isIndividual = false) as groupSelect, 
participant p where p.contender = contID group by p.contender) as lastSelection
where formedBy<2
)
then 'false'
else 'true' END
;

     